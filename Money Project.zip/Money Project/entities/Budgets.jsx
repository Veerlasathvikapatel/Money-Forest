{
  "name": "Goal",
  "type": "object",
  "properties": {
    "name": {
      "type": "string",
      "description": "Goal name"
    },
    "target_amount": {
      "type": "number",
      "description": "Target amount to reach"
    },
    "current_amount": {
      "type": "number",
      "description": "Current saved amount"
    },
    "icon": {
      "type": "string",
      "enum": [
        "emergency",
        "travel",
        "education",
        "gadget",
        "home",
        "car",
        "wedding",
        "other"
      ],
      "description": "Goal icon type"
    },
    "deadline": {
      "type": "string",
      "format": "date",
      "description": "Goal deadline"
    },
    "status": {
      "type": "string",
      "enum": [
        "active",
        "completed",
        "paused"
      ],
      "default": "active",
      "description": "Goal status"
    }
  },
  "required": [
    "name",
    "target_amount",
    "icon"
  ]
}