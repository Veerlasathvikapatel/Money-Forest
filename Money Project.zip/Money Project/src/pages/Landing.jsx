import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Leaf, Target, TrendingUp, Shield, ArrowRight, Sprout } from 'lucide-react';

const features = [
  {
    icon: '🌱',
    title: 'Save → Trees Grow',
    desc: 'Every dollar saved grows a tree in your personal forest ecosystem.',
  },
  {
    icon: '🎯',
    title: 'Goals Bloom Flowers',
    desc: 'Set financial goals and watch them blossom as you make progress.',
  },
  {
    icon: '📊',
    title: 'Visual Health Score',
    desc: 'Your forest reflects your financial health — sunny skies or stormy clouds.',
  },
  {
    icon: '🔥',
    title: 'Streak Habits',
    desc: 'Build daily logging habits and earn forest badges for consistency.',
  },
];

const stats = [
  { value: '60s', label: 'to plant your first tree' },
  { value: '100%', label: 'visual & fun' },
  { value: '0 stress', label: 'finance for Gen Z' },
];

export default function Landing() {
  const goToAuth = () => base44.auth.redirectToLogin(window.location.origin + '/Forest');

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">

      {/* Nav */}
      <nav className="flex items-center justify-between px-6 md:px-12 py-5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-primary/15 flex items-center justify-center">
            <Sprout className="w-4 h-4 text-primary" />
          </div>
          <span className="font-display font-semibold text-foreground text-lg">Money Forest</span>
        </div>
        <button
          onClick={goToAuth}
          className="text-sm font-medium px-4 py-2 rounded-xl border border-border hover:bg-muted transition-colors text-foreground"
        >
          Sign in →
        </button>
      </nav>

      {/* Hero */}
      <section className="relative px-6 md:px-12 pt-12 pb-20 text-center overflow-hidden">
        {/* Background forest blur blobs */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl -z-10" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-accent/15 rounded-full blur-3xl -z-10" />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <span className="inline-flex items-center gap-2 bg-primary/10 text-primary text-xs font-semibold px-3 py-1.5 rounded-full mb-6 border border-primary/20">
            <Leaf className="w-3 h-3" /> For Gen Z who hate spreadsheets
          </span>

          <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold text-foreground leading-tight mb-6">
            Grow Your{' '}
            <span className="text-primary relative">
              Financial Forest
              <svg className="absolute -bottom-1 left-0 w-full" height="6" viewBox="0 0 200 6" fill="none">
                <path d="M0 5 Q50 0 100 5 Q150 10 200 5" stroke="hsl(var(--primary))" strokeWidth="2.5" fill="none" strokeLinecap="round" />
              </svg>
            </span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-4 leading-relaxed">
            Track your money the way nature grows — beautifully. Save money, plant trees.
            Reach goals, bloom flowers. Your finances, visualized as a living forest.
          </p>

          <p className="text-sm text-primary/80 font-medium mb-8">
            🌱 New here? Register first to create your forest — free, no credit card needed.
          </p>

          <div className="flex flex-col items-center gap-3 w-full sm:w-auto">
            {/* Primary: Register */}
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={goToAuth}
              className="inline-flex items-center justify-center gap-2.5 px-10 py-4 bg-primary text-primary-foreground rounded-2xl font-bold text-base shadow-xl hover:bg-primary/90 transition-colors w-full sm:w-auto"
            >
              🌳 Register — Create My Forest Free
              <ArrowRight className="w-4 h-4" />
            </motion.button>

            {/* Divider */}
            <div className="flex items-center gap-3 w-full sm:w-80 my-1">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs text-muted-foreground">already have an account?</span>
              <div className="flex-1 h-px bg-border" />
            </div>

            {/* Secondary: Login */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              onClick={goToAuth}
              className="inline-flex items-center justify-center gap-2 px-8 py-3 bg-card border border-border text-foreground rounded-2xl font-semibold text-sm hover:bg-muted transition-colors w-full sm:w-auto"
            >
              Sign In to My Forest
            </motion.button>
          </div>
        </motion.div>

        {/* Forest illustration */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-14 mx-auto max-w-2xl"
        >
          <div className="bg-card border border-border rounded-3xl p-6 shadow-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-sky-50 to-green-50 opacity-60" />
            <div className="relative">
              {/* Mini forest scene */}
              <svg viewBox="0 0 500 200" className="w-full" style={{ height: 180 }}>
                {/* Sky gradient */}
                <defs>
                  <linearGradient id="heroSky" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#bfdbfe" />
                    <stop offset="100%" stopColor="#dcfce7" />
                  </linearGradient>
                </defs>
                <rect width="500" height="200" fill="url(#heroSky)" />
                {/* Sun */}
                <circle cx="420" cy="40" r="22" fill="#fde68a" opacity="0.9" />
                <circle cx="420" cy="40" r="15" fill="#fef3c7" />
                {/* Ground */}
                <rect x="0" y="155" width="500" height="50" fill="#4ade80" opacity="0.6" rx="20" />
                <rect x="0" y="165" width="500" height="40" fill="#22c55e" opacity="0.4" />
                {/* Trees */}
                {[
                  { x: 80, h: 80, c: '#15803d' },
                  { x: 160, h: 110, c: '#16a34a' },
                  { x: 250, h: 130, c: '#166534' },
                  { x: 340, h: 100, c: '#16a34a' },
                  { x: 420, h: 70, c: '#15803d' },
                ].map((t, i) => (
                  <g key={i}>
                    <rect x={t.x - 5} y={155 - 25} width={10} height={25} rx={3} fill="#92400e" />
                    <ellipse cx={t.x} cy={155 - 25 - t.h * 0.5} rx={t.h * 0.35} ry={t.h * 0.5} fill={t.c} opacity={0.75} />
                    <ellipse cx={t.x} cy={155 - 25 - t.h * 0.7} rx={t.h * 0.27} ry={t.h * 0.38} fill={t.c} opacity={0.9} />
                    <ellipse cx={t.x} cy={155 - 25 - t.h * 0.88} rx={t.h * 0.18} ry={t.h * 0.25} fill={t.c} />
                  </g>
                ))}
                {/* Flowers */}
                {[120, 200, 290, 380].map((fx, i) => (
                  <circle key={i} cx={fx} cy={152} r={5} fill={['#f9a8d4', '#fde68a', '#a5f3fc', '#bbf7d0'][i]} />
                ))}
                {/* Birds */}
                <path d="M50 30 q-4 -4 -8 0" stroke="#64748b" strokeWidth="1.5" fill="none" />
                <path d="M50 30 q4 -4 8 0" stroke="#64748b" strokeWidth="1.5" fill="none" />
                <path d="M70 20 q-3 -3 -6 0" stroke="#64748b" strokeWidth="1.2" fill="none" />
                <path d="M70 20 q3 -3 6 0" stroke="#64748b" strokeWidth="1.2" fill="none" />
              </svg>

              {/* Score badge overlay */}
              <div className="absolute top-3 left-4 bg-white/90 backdrop-blur-sm border border-green-100 rounded-2xl px-4 py-2.5 shadow-sm">
                <p className="text-xs text-muted-foreground">Forest Health</p>
                <p className="text-xl font-bold text-primary font-display">82 🌿</p>
              </div>

              {/* Stat chips */}
              <div className="absolute bottom-4 right-4 flex flex-col gap-2">
                <div className="bg-white/90 backdrop-blur-sm border border-green-100 rounded-xl px-3 py-1.5 text-xs font-medium text-green-700 shadow-sm">
                  💰 $1,240 saved
                </div>
                <div className="bg-white/90 backdrop-blur-sm border border-blue-100 rounded-xl px-3 py-1.5 text-xs font-medium text-blue-600 shadow-sm">
                  🎯 3 goals active
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Stats bar */}
      <section className="px-6 md:px-12 py-8 border-y border-border bg-card/50">
        <div className="max-w-3xl mx-auto flex flex-col sm:flex-row gap-6 sm:gap-0 justify-around items-center">
          {stats.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="text-center"
            >
              <p className="font-display text-3xl font-bold text-primary">{s.value}</p>
              <p className="text-sm text-muted-foreground mt-1">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="px-6 md:px-12 py-20 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-center mb-14"
        >
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Finance that feels like a game 🎮
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            No boring charts. No anxiety. Just a living, breathing forest that grows with your wallet.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-card border border-border rounded-2xl p-6 hover:shadow-md transition-shadow"
            >
              <span className="text-3xl mb-4 block">{f.icon}</span>
              <h3 className="font-semibold text-foreground mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="px-6 md:px-12 py-16 bg-primary/5 border-y border-primary/10">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="font-display text-3xl font-bold text-foreground mb-3">Get started in 60 seconds</h2>
          <p className="text-muted-foreground">Three steps to your first tree.</p>
        </div>
        <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { step: '01', emoji: '🌰', title: 'Sign Up Free', desc: 'Create your account in seconds. No credit card.' },
            { step: '02', emoji: '🎯', title: 'Set a Goal', desc: 'Name your first savings goal — emergency fund, trip, anything.' },
            { step: '03', emoji: '🌱', title: 'Watch it Grow', desc: 'Log a transaction and your first tree sprouts instantly.' },
          ].map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.15 }}
              className="text-center"
            >
              <div className="text-4xl mb-3">{s.emoji}</div>
              <p className="text-xs font-bold text-primary/60 tracking-widest mb-1">{s.step}</p>
              <h3 className="font-semibold text-foreground mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 md:px-12 py-24 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          className="max-w-xl mx-auto"
        >
          <div className="text-5xl mb-6">🌳</div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Your forest is waiting
          </h2>
          <p className="text-muted-foreground mb-2">
            Create your account and start growing your financial forest instantly.
          </p>
          <p className="text-sm text-muted-foreground mb-8">
            Takes less than 60 seconds. No complexity.
          </p>
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            onClick={goToAuth}
            className="inline-flex items-center gap-2.5 px-10 py-4 bg-primary text-primary-foreground rounded-2xl font-bold text-lg shadow-xl hover:bg-primary/90 transition-colors"
          >
            Plant Your First Tree
            <ArrowRight className="w-5 h-5" />
          </motion.button>
          <p className="text-xs text-muted-foreground mt-3">Free forever · No credit card · Takes 60 seconds</p>
          <button onClick={goToAuth} className="mt-3 text-xs text-muted-foreground hover:text-foreground underline underline-offset-4 transition-colors">
            Already have an account? Sign in
          </button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="px-6 md:px-12 py-8 border-t border-border text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Sprout className="w-4 h-4 text-primary" />
          <span className="font-display font-semibold text-foreground">Money Forest</span>
        </div>
        <p className="text-xs text-muted-foreground">Your financial garden grows with you. 🌿</p>
      </footer>
    </div>
  );
}