import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { Trash2, TrendingUp, TrendingDown, PiggyBank, DollarSign, Filter } from 'lucide-react';
import QuickAddTransaction from '@/components/transactions/QuickAddTransaction';
import { cn } from '@/lib/utils';
import { useAuth } from '@/lib/AuthContext';

const TYPE_CONFIG = {
  income: { icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-100', sign: '+' },
  expense: { icon: TrendingDown, color: 'text-red-500', bg: 'bg-red-100', sign: '-' },
  savings: { icon: PiggyBank, color: 'text-blue-600', bg: 'bg-blue-100', sign: '+' },
  investment: { icon: DollarSign, color: 'text-purple-600', bg: 'bg-purple-100', sign: '+' },
};

export default function Transactions() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [filter, setFilter] = useState('all');

  const { data: transactions = [], refetch } = useQuery({
    queryKey: ['transactions', user?.email],
    queryFn: () => base44.entities.Transaction.filter({ created_by: user.email }, '-date', 200),
    enabled: !!user?.email,
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Transaction.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['transactions'] }),
  });

  const filtered = filter === 'all' ? transactions : transactions.filter(t => t.type === filter);

  const grouped = filtered.reduce((acc, t) => {
    const key = t.date;
    if (!acc[key]) acc[key] = [];
    acc[key].push(t);
    return acc;
  }, {});

  const sortedDates = Object.keys(grouped).sort((a, b) => new Date(b) - new Date(a));

  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 md:px-8 pt-6 pb-4 flex items-start justify-between">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-semibold">Transactions</h1>
          <p className="text-sm text-muted-foreground mt-1">{transactions.length} entries logged</p>
        </div>
        <QuickAddTransaction onAdded={() => refetch()} />
      </div>

      {/* Filter tabs */}
      <div className="px-4 md:px-8 mb-4">
        <div className="flex gap-2 overflow-x-auto pb-1">
          {['all', 'income', 'expense', 'savings', 'investment'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                'px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-colors border',
                filter === f
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'bg-card border-border text-muted-foreground hover:bg-muted'
              )}
            >
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Transaction list */}
      <div className="px-4 md:px-8 space-y-6 pb-10">
        {sortedDates.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <span className="text-5xl mb-4">🌿</span>
            <h3 className="font-display font-semibold text-lg mb-2">No transactions yet</h3>
            <p className="text-sm text-muted-foreground">Start logging to see your forest grow.</p>
          </div>
        )}

        {sortedDates.map(date => (
          <div key={date}>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              {format(new Date(date + 'T12:00:00'), 'EEEE, MMMM d')}
            </p>
            <div className="space-y-2">
              <AnimatePresence>
                {grouped[date].map(tx => {
                  const cfg = TYPE_CONFIG[tx.type] || TYPE_CONFIG.expense;
                  const Icon = cfg.icon;
                  return (
                    <motion.div
                      key={tx.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="bg-card border border-border rounded-xl px-4 py-3.5 flex items-center gap-3 group"
                    >
                      <div className={`w-9 h-9 rounded-xl ${cfg.bg} flex items-center justify-center shrink-0`}>
                        <Icon className={`w-4 h-4 ${cfg.color}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground capitalize">
                          {tx.category?.replace(/_/g, ' ')}
                        </p>
                        {tx.note && <p className="text-xs text-muted-foreground truncate">{tx.note}</p>}
                      </div>
                      <div className="text-right">
                        <p className={cn('text-sm font-semibold', tx.type === 'expense' ? 'text-red-500' : 'text-green-600')}>
                          {cfg.sign}${tx.amount.toLocaleString()}
                        </p>
                        <p className="text-xs text-muted-foreground capitalize">{tx.type}</p>
                      </div>
                      <button
                        onClick={() => deleteMutation.mutate(tx.id)}
                        className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg hover:bg-muted text-muted-foreground transition-opacity"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}