import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import GoalTree from '@/components/goals/GoalTree';
import { Plus, X, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const GOAL_ICONS = ['emergency', 'travel', 'education', 'gadget', 'home', 'car', 'wedding', 'other'];
const ICON_LABELS = {
  emergency: '🛡️ Emergency',
  travel: '✈️ Travel',
  education: '📚 Education',
  gadget: '💻 Gadget',
  home: '🏠 Home',
  car: '🚗 Car',
  wedding: '💍 Wedding',
  other: '⭐ Other',
};

export default function Goals() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [showDeposit, setShowDeposit] = useState(null);
  const [depositAmount, setDepositAmount] = useState('');
  const [form, setForm] = useState({ name: '', target_amount: '', icon: 'travel', deadline: '' });

  const { data: goals = [] } = useQuery({
    queryKey: ['goals', user?.email],
    queryFn: () => base44.entities.Goal.filter({ created_by: user.email }, '-created_date', 50),
    enabled: !!user?.email,
  });

  const createGoal = useMutation({
    mutationFn: (data) => base44.entities.Goal.create({ ...data, current_amount: 0, status: 'active' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['goals'] });
      setShowForm(false);
      setForm({ name: '', target_amount: '', icon: 'travel', deadline: '' });
    },
  });

  const updateGoal = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Goal.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['goals'] }),
  });

  const deleteGoal = useMutation({
    mutationFn: (id) => base44.entities.Goal.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['goals'] }),
  });

  const handleDeposit = async (goal) => {
    const amt = parseFloat(depositAmount);
    if (!amt) return;
    const newAmt = (goal.current_amount || 0) + amt;
    const completed = newAmt >= goal.target_amount;
    await updateGoal.mutateAsync({
      id: goal.id,
      data: { current_amount: newAmt, status: completed ? 'completed' : 'active' },
    });
    // Also log as savings transaction
    await base44.entities.Transaction.create({
      type: 'savings',
      amount: amt,
      category: 'savings_deposit',
      note: `Goal: ${goal.name}`,
      date: new Date().toISOString().split('T')[0],
    });
    queryClient.invalidateQueries({ queryKey: ['transactions'] });
    setShowDeposit(null);
    setDepositAmount('');
  };

  const activeGoals = goals.filter(g => g.status === 'active');
  const completedGoals = goals.filter(g => g.status === 'completed');

  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 md:px-8 pt-6 pb-4 flex items-start justify-between">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-semibold">Goal Trees</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {activeGoals.length} growing · {completedGoals.length} completed
          </p>
        </div>
        <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          New Goal
        </Button>
      </div>

      <div className="px-4 md:px-8 pb-10 space-y-8">
        {/* Emergency Fund spotlight */}
        {(() => {
          const ef = goals.find(g => g.icon === 'emergency' && g.status === 'active');
          if (!ef) return null;
          const progress = Math.min(100, ((ef.current_amount || 0) / ef.target_amount) * 100);
          const isGolden = progress >= 100;
          return (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={() => setShowDeposit(ef)}
              className={`rounded-2xl border p-5 cursor-pointer hover:shadow-md transition-shadow ${
                isGolden ? 'bg-yellow-50 border-yellow-200' : 'bg-card border-primary/20'
              }`}
            >
              <div className="flex items-center gap-3 mb-4">
                <span className="text-3xl">{isGolden ? '🌟' : '🛡️'}</span>
                <div>
                  <h3 className="font-semibold text-foreground">{ef.name}</h3>
                  <p className="text-xs text-muted-foreground">
                    {isGolden ? 'Golden leaves! Emergency fund complete! ✨' : 'Emergency Tree — tap to water it 💧'}
                  </p>
                </div>
                <div className="ml-auto text-right">
                  <p className="font-bold text-lg text-foreground">{Math.round(progress)}%</p>
                  <p className="text-xs text-muted-foreground">${(ef.current_amount||0).toLocaleString()} / ${ef.target_amount.toLocaleString()}</p>
                </div>
              </div>
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                  className={`h-full rounded-full ${isGolden ? 'bg-yellow-400' : 'bg-primary'}`}
                />
              </div>
            </motion.div>
          );
        })()}

        {/* Active goals */}
        {activeGoals.length > 0 && (
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Growing 🌱</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {activeGoals.map(goal => (
                <div key={goal.id} className="relative group">
                  <div onClick={() => setShowDeposit(goal)}>
                    <GoalTree goal={goal} />
                  </div>
                  <button
                    onClick={() => deleteGoal.mutate(goal.id)}
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1.5 rounded-full bg-white shadow-sm hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-all"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Completed goals */}
        {completedGoals.length > 0 && (
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Completed 🎉</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {completedGoals.map(goal => <GoalTree key={goal.id} goal={goal} />)}
            </div>
          </div>
        )}

        {/* Empty state */}
        {goals.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <span className="text-5xl mb-4">🌱</span>
            <h3 className="font-display font-semibold text-xl mb-2">Plant your first goal tree</h3>
            <p className="text-sm text-muted-foreground mb-6 max-w-xs">
              Every financial goal becomes a tree in your forest. Watch it grow as you save!
            </p>
            <Button onClick={() => setShowForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create First Goal
            </Button>
          </div>
        )}
      </div>

      {/* Create goal modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-card rounded-2xl p-6 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-display font-semibold text-xl">Plant a New Tree 🌱</h3>
                <button onClick={() => setShowForm(false)} className="p-1.5 rounded-full hover:bg-muted text-muted-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Goal Name</label>
                  <Input
                    placeholder="e.g. Japan Trip Fund"
                    value={form.name}
                    onChange={e => setForm({ ...form, name: e.target.value })}
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Target Amount</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                    <Input
                      type="number"
                      placeholder="0.00"
                      className="pl-7"
                      value={form.target_amount}
                      onChange={e => setForm({ ...form, target_amount: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Goal Type</label>
                  <div className="grid grid-cols-4 gap-2">
                    {GOAL_ICONS.map(icon => (
                      <button
                        key={icon}
                        onClick={() => setForm({ ...form, icon })}
                        className={cn(
                          'p-2.5 rounded-xl border text-xs text-center transition-colors',
                          form.icon === icon
                            ? 'bg-primary/10 border-primary text-primary font-medium'
                            : 'border-border text-muted-foreground hover:bg-muted'
                        )}
                      >
                        {ICON_LABELS[icon]}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Deadline (optional)</label>
                  <Input
                    type="date"
                    value={form.deadline}
                    onChange={e => setForm({ ...form, deadline: e.target.value })}
                  />
                </div>

                <Button
                  className="w-full h-11"
                  disabled={!form.name || !form.target_amount || createGoal.isPending}
                  onClick={() => createGoal.mutate({
                    name: form.name,
                    target_amount: parseFloat(form.target_amount),
                    icon: form.icon,
                    deadline: form.deadline || null,
                  })}
                >
                  {createGoal.isPending ? 'Planting…' : 'Plant This Tree 🌳'}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Deposit modal */}
      <AnimatePresence>
        {showDeposit && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
            onClick={() => setShowDeposit(null)}
          >
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              className="w-full max-w-sm bg-card rounded-2xl p-6 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-display font-semibold text-lg">Water this Tree 💧</h3>
                  <p className="text-xs text-muted-foreground">{showDeposit.name}</p>
                </div>
                <button onClick={() => setShowDeposit(null)} className="p-1.5 rounded-full hover:bg-muted text-muted-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-sm text-muted-foreground mb-4">
                Current: ${(showDeposit.current_amount || 0).toLocaleString()} / ${showDeposit.target_amount.toLocaleString()}
              </p>

              <div className="relative mb-4">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                <Input
                  type="number"
                  placeholder="How much to add?"
                  className="pl-7 text-lg h-12"
                  value={depositAmount}
                  onChange={e => setDepositAmount(e.target.value)}
                  autoFocus
                />
              </div>

              <Button
                className="w-full h-11"
                disabled={!depositAmount || updateGoal.isPending}
                onClick={() => handleDeposit(showDeposit)}
              >
                {updateGoal.isPending ? 'Watering…' : 'Add to Goal 🌱'}
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}