import { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, X, AlertTriangle, CheckCircle2, Leaf } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { useAuth } from '@/lib/AuthContext';

const CATEGORIES = ['food', 'transport', 'shopping', 'entertainment', 'bills', 'health', 'education', 'travel', 'other'];

const CAT_META = {
  food: { emoji: '🍱', color: 'bg-orange-50 border-orange-100', bar: 'bg-orange-400' },
  transport: { emoji: '🚌', color: 'bg-blue-50 border-blue-100', bar: 'bg-blue-400' },
  shopping: { emoji: '🛍️', color: 'bg-pink-50 border-pink-100', bar: 'bg-pink-400' },
  entertainment: { emoji: '🎬', color: 'bg-purple-50 border-purple-100', bar: 'bg-purple-400' },
  bills: { emoji: '🧾', color: 'bg-gray-50 border-gray-200', bar: 'bg-gray-400' },
  health: { emoji: '💊', color: 'bg-red-50 border-red-100', bar: 'bg-red-400' },
  education: { emoji: '📚', color: 'bg-indigo-50 border-indigo-100', bar: 'bg-indigo-400' },
  travel: { emoji: '✈️', color: 'bg-sky-50 border-sky-100', bar: 'bg-sky-400' },
  other: { emoji: '📦', color: 'bg-muted border-border', bar: 'bg-muted-foreground' },
};

export default function Budgets() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ category: 'food', limit: '' });

  const currentMonth = format(new Date(), 'yyyy-MM');

  const { data: budgets = [] } = useQuery({
    queryKey: ['budgets', currentMonth, user?.email],
    queryFn: () => base44.entities.Budget.filter({ month: currentMonth, created_by: user.email }),
    enabled: !!user?.email,
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', user?.email],
    queryFn: () => base44.entities.Transaction.filter({ created_by: user.email }, '-date', 200),
    enabled: !!user?.email,
  });

  const createBudget = useMutation({
    mutationFn: (data) => base44.entities.Budget.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['budgets'] });
      setShowForm(false);
      setForm({ category: 'food', limit: '' });
    },
  });

  const deleteBudget = useMutation({
    mutationFn: (id) => base44.entities.Budget.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['budgets'] }),
  });

  // Calculate spending per category this month
  const spendingByCategory = useMemo(() => {
    const now = new Date();
    return transactions
      .filter(t => {
        const d = new Date(t.date);
        return t.type === 'expense' && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      })
      .reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount;
        return acc;
      }, {});
  }, [transactions]);

  const existingCategories = budgets.map(b => b.category);
  const availableCategories = CATEGORIES.filter(c => !existingCategories.includes(c));

  // Forest impact summary
  const overBudgetCount = budgets.filter(b => (spendingByCategory[b.category] || 0) > b.limit).length;
  const onTrackCount = budgets.filter(b => (spendingByCategory[b.category] || 0) <= b.limit * 0.8).length;

  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 md:px-8 pt-6 pb-4 flex items-start justify-between">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-semibold">Budget Garden</h1>
          <p className="text-sm text-muted-foreground mt-1">{format(new Date(), 'MMMM yyyy')} limits</p>
        </div>
        {availableCategories.length > 0 && (
          <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Budget
          </Button>
        )}
      </div>

      <div className="px-4 md:px-8 pb-10 space-y-5">
        {/* Forest impact banner */}
        {budgets.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className={cn(
              'rounded-2xl border p-4 flex items-center gap-4',
              overBudgetCount > 0
                ? 'bg-red-50 border-red-100'
                : 'bg-green-50 border-green-100'
            )}
          >
            <span className="text-3xl">{overBudgetCount > 0 ? '🌿' : '🌸'}</span>
            <div>
              <p className="font-semibold text-sm">
                {overBudgetCount > 0
                  ? `${overBudgetCount} budget${overBudgetCount > 1 ? 's' : ''} exceeded — weeds are growing!`
                  : `${onTrackCount} budget${onTrackCount > 1 ? 's' : ''} on track — flowers are blooming!`}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {overBudgetCount > 0
                  ? 'Reduce overspending to clear weeds from your forest.'
                  : 'Great discipline! Your forest is thriving.'}
              </p>
            </div>
          </motion.div>
        )}

        {/* Budget cards */}
        {budgets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <span className="text-5xl mb-4">🌻</span>
            <h3 className="font-display font-semibold text-xl mb-2">Set your spending limits</h3>
            <p className="text-sm text-muted-foreground mb-6 max-w-xs">
              Budgets help your forest stay healthy. Staying within limits makes flowers bloom.
            </p>
            <Button onClick={() => setShowForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create First Budget
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <AnimatePresence>
              {budgets.map((budget, i) => {
                const spent = spendingByCategory[budget.category] || 0;
                const pct = Math.min(100, (spent / budget.limit) * 100);
                const over = spent > budget.limit;
                const nearLimit = pct >= 80 && !over;
                const meta = CAT_META[budget.category] || CAT_META.other;

                return (
                  <motion.div
                    key={budget.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ delay: i * 0.05 }}
                    className={cn('rounded-2xl border p-5 group relative', meta.color)}
                  >
                    <button
                      onClick={() => deleteBudget.mutate(budget.id)}
                      className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 p-1 rounded-full hover:bg-white/80 text-muted-foreground transition-all"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-2xl">{meta.emoji}</span>
                      <div>
                        <p className="font-semibold capitalize text-foreground">{budget.category}</p>
                        <p className="text-xs text-muted-foreground">
                          ${spent.toLocaleString()} of ${budget.limit.toLocaleString()} spent
                        </p>
                      </div>
                      <div className="ml-auto">
                        {over ? (
                          <AlertTriangle className="w-4 h-4 text-red-500" />
                        ) : nearLimit ? (
                          <AlertTriangle className="w-4 h-4 text-amber-500" />
                        ) : (
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                        )}
                      </div>
                    </div>

                    <div className="h-2 bg-white/60 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.8, ease: 'easeOut' }}
                        className={cn('h-full rounded-full', over ? 'bg-red-500' : nearLimit ? 'bg-amber-400' : meta.bar)}
                      />
                    </div>

                    <div className="flex justify-between mt-2">
                      <span className={cn('text-xs font-medium', over ? 'text-red-600' : nearLimit ? 'text-amber-600' : 'text-green-600')}>
                        {over ? `$${(spent - budget.limit).toLocaleString()} over` : `$${(budget.limit - spent).toLocaleString()} left`}
                      </span>
                      <span className="text-xs text-muted-foreground">{Math.round(pct)}%</span>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Create budget modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              className="w-full max-w-sm bg-card rounded-2xl p-6 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-display font-semibold text-lg">Set Monthly Limit 🌻</h3>
                <button onClick={() => setShowForm(false)} className="p-1.5 rounded-full hover:bg-muted text-muted-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-2 block">Category</label>
                  <div className="grid grid-cols-3 gap-2">
                    {availableCategories.map(cat => {
                      const meta = CAT_META[cat] || CAT_META.other;
                      return (
                        <button
                          key={cat}
                          onClick={() => setForm({ ...form, category: cat })}
                          className={cn(
                            'p-2.5 rounded-xl border text-xs text-center transition-colors flex flex-col items-center gap-1',
                            form.category === cat
                              ? 'bg-primary/10 border-primary text-primary font-medium'
                              : 'border-border text-muted-foreground hover:bg-muted'
                          )}
                        >
                          <span>{meta.emoji}</span>
                          <span className="capitalize">{cat}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Monthly Limit</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                    <Input
                      type="number"
                      placeholder="0.00"
                      className="pl-7 h-11"
                      value={form.limit}
                      onChange={e => setForm({ ...form, limit: e.target.value })}
                      autoFocus
                    />
                  </div>
                </div>

                <Button
                  className="w-full h-11"
                  disabled={!form.limit || createBudget.isPending}
                  onClick={() => createBudget.mutate({
                    category: form.category,
                    limit: parseFloat(form.limit),
                    month: currentMonth,
                  })}
                >
                  {createBudget.isPending ? 'Planting…' : 'Set Budget 🌻'}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}