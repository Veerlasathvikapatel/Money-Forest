import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { calculateHealthScore, getForestState, getForestConfig } from '@/lib/forestEngine';
import HealthScoreBadge from '@/components/forest/HealthScoreBadge';
import QuickAddTransaction from '@/components/transactions/QuickAddTransaction';
import { TrendingUp, TrendingDown, PiggyBank, DollarSign } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { useAuth } from '@/lib/AuthContext';

const COLORS = ['#22c55e', '#ef4444', '#3b82f6', '#a855f7'];

export default function Dashboard() {
  const { user } = useAuth();
  const firstName = user?.full_name?.split(' ')[0] || user?.email?.split('@')[0] || 'Forester';

  const { data: transactions = [], refetch } = useQuery({
    queryKey: ['transactions', user?.email],
    queryFn: () => base44.entities.Transaction.filter({ created_by: user.email }, '-date', 200),
    enabled: !!user?.email,
  });

  const { data: goals = [] } = useQuery({
    queryKey: ['goals', user?.email],
    queryFn: () => base44.entities.Goal.filter({ created_by: user.email }, '-created_date', 20),
    enabled: !!user?.email,
  });

  const score = useMemo(() => calculateHealthScore(transactions), [transactions]);

  const now = new Date();
  const thisMonth = transactions.filter(t => {
    const d = new Date(t.date);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });

  const totals = {
    income: thisMonth.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0),
    expense: thisMonth.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0),
    savings: thisMonth.filter(t => t.type === 'savings').reduce((s, t) => s + t.amount, 0),
    investment: thisMonth.filter(t => t.type === 'investment').reduce((s, t) => s + t.amount, 0),
  };

  // Last 7 days chart data
  const chartData = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const date = subDays(now, 6 - i);
      const dateStr = format(date, 'yyyy-MM-dd');
      const dayTx = transactions.filter(t => t.date === dateStr);
      return {
        day: format(date, 'EEE'),
        income: dayTx.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0),
        expense: dayTx.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0),
        savings: dayTx.filter(t => t.type === 'savings').reduce((s, t) => s + t.amount, 0),
      };
    });
  }, [transactions]);

  // Category breakdown for expenses
  const categoryData = useMemo(() => {
    const cats = {};
    thisMonth.filter(t => t.type === 'expense').forEach(t => {
      cats[t.category] = (cats[t.category] || 0) + t.amount;
    });
    return Object.entries(cats)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, value]) => ({ name: name.replace(/_/g, ' '), value }));
  }, [thisMonth]);

  const stats = [
    { label: 'Income', value: totals.income, icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-50 border-green-100' },
    { label: 'Expenses', value: totals.expense, icon: TrendingDown, color: 'text-red-500', bg: 'bg-red-50 border-red-100' },
    { label: 'Savings', value: totals.savings, icon: PiggyBank, color: 'text-blue-600', bg: 'bg-blue-50 border-blue-100' },
    { label: 'Invested', value: totals.investment, icon: DollarSign, color: 'text-purple-600', bg: 'bg-purple-50 border-purple-100' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 md:px-8 pt-6 pb-4 flex items-start justify-between">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-semibold">Hey, {firstName} 👋</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Your {format(now, 'MMMM yyyy')} overview
          </p>
        </div>
        <QuickAddTransaction onAdded={() => refetch()} />
      </div>

      <div className="px-4 md:px-8 space-y-6 pb-10">
        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {stats.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className={`bg-card border ${s.bg} rounded-2xl p-4`}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${s.bg}`}>
                    <Icon className={`w-3.5 h-3.5 ${s.color}`} />
                  </div>
                  <span className="text-xs font-medium text-muted-foreground">{s.label}</span>
                </div>
                <p className="font-display text-xl font-semibold text-foreground">
                  ${s.value.toLocaleString()}
                </p>
                <p className="text-xs text-muted-foreground mt-1">This month</p>
              </motion.div>
            );
          })}
        </div>

        {/* Chart + Health Score */}
        <div className="grid md:grid-cols-3 gap-4">
          {/* Area chart */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="md:col-span-2 bg-card border border-border rounded-2xl p-5"
          >
            <h2 className="font-semibold text-sm mb-4">7-Day Activity</h2>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="incomeGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="expenseGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} width={40} />
                <Tooltip
                  contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 12, fontSize: 12 }}
                  formatter={(val) => [`$${val}`, '']}
                />
                <Area type="monotone" dataKey="income" stroke="#22c55e" fill="url(#incomeGrad)" strokeWidth={2} />
                <Area type="monotone" dataKey="expense" stroke="#ef4444" fill="url(#expenseGrad)" strokeWidth={2} />
                <Area type="monotone" dataKey="savings" stroke="#3b82f6" fill="none" strokeWidth={2} strokeDasharray="4 2" />
              </AreaChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-3">
              {[['#22c55e', 'Income'], ['#ef4444', 'Expenses'], ['#3b82f6', 'Savings']].map(([color, label]) => (
                <div key={label} className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
                  <span className="text-xs text-muted-foreground">{label}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Health score */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-card border border-border rounded-2xl p-5 flex flex-col items-center justify-center gap-4"
          >
            <h2 className="font-semibold text-sm self-start">Forest Health</h2>
            <HealthScoreBadge score={score} size="lg" />
          </motion.div>
        </div>

        {/* Expense Breakdown + Goals */}
        <div className="grid md:grid-cols-2 gap-4">
          {/* Pie chart */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 }}
            className="bg-card border border-border rounded-2xl p-5"
          >
            <h2 className="font-semibold text-sm mb-4">Expense Breakdown</h2>
            {categoryData.length > 0 ? (
              <div className="flex items-center gap-4">
                <PieChart width={120} height={120}>
                  <Pie data={categoryData} cx={55} cy={55} innerRadius={35} outerRadius={55} dataKey="value" paddingAngle={3}>
                    {categoryData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                </PieChart>
                <div className="space-y-2 flex-1">
                  {categoryData.map((item, i) => (
                    <div key={item.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                        <span className="text-xs capitalize text-muted-foreground">{item.name}</span>
                      </div>
                      <span className="text-xs font-medium">${item.value.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-32 text-center">
                <span className="text-3xl mb-2">📊</span>
                <p className="text-xs text-muted-foreground">No expenses logged yet</p>
              </div>
            )}
          </motion.div>

          {/* Goals progress */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-card border border-border rounded-2xl p-5"
          >
            <h2 className="font-semibold text-sm mb-4">Goal Progress</h2>
            {goals.filter(g => g.status === 'active').length > 0 ? (
              <div className="space-y-3">
                {goals.filter(g => g.status === 'active').slice(0, 4).map(goal => {
                  const progress = goal.target_amount > 0
                    ? Math.min(100, ((goal.current_amount || 0) / goal.target_amount) * 100)
                    : 0;
                  return (
                    <div key={goal.id}>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-medium truncate">{goal.name}</span>
                        <span className="text-xs text-muted-foreground ml-2">{Math.round(progress)}%</span>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                          transition={{ duration: 0.8, ease: 'easeOut' }}
                          className="h-full bg-primary rounded-full"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-32 text-center">
                <span className="text-3xl mb-2">🌱</span>
                <p className="text-xs text-muted-foreground">No goals yet. Plant your first tree!</p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}