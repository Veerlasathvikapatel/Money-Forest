import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { motion } from 'framer-motion';
import { calculateHealthScore, getForestState, getForestConfig, generateForestMessage } from '@/lib/forestEngine';
import HealthScoreBadge from '@/components/forest/HealthScoreBadge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Sparkles, Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format, subMonths, startOfMonth, endOfMonth } from 'date-fns';

export default function Report() {
  const { user } = useAuth();
  const [aiInsight, setAiInsight] = useState('');
  const [loadingAI, setLoadingAI] = useState(false);

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', user?.email],
    queryFn: () => base44.entities.Transaction.filter({ created_by: user.email }, '-date', 200),
    enabled: !!user?.email,
  });

  const { data: goals = [] } = useQuery({
    queryKey: ['goals', user?.email],
    queryFn: () => base44.entities.Goal.filter({ created_by: user.email }, '-created_date', 20),
    enabled: !!user?.email,
  });

  const score = useMemo(() => calculateHealthScore(transactions), [transactions]);
  const state = getForestState(score);
  const config = getForestConfig(state);
  const forestMessage = useMemo(() => generateForestMessage(transactions, goals, score), [transactions, goals, score]);

  // Last 6 months data
  const monthlyData = useMemo(() => {
    return Array.from({ length: 6 }, (_, i) => {
      const month = subMonths(new Date(), 5 - i);
      const start = startOfMonth(month);
      const end = endOfMonth(month);
      const monthTx = transactions.filter(t => {
        const d = new Date(t.date);
        return d >= start && d <= end;
      });
      return {
        month: format(month, 'MMM'),
        income: monthTx.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0),
        expense: monthTx.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0),
        savings: monthTx.filter(t => t.type === 'savings').reduce((s, t) => s + t.amount, 0),
      };
    });
  }, [transactions]);

  const generateAIInsight = async () => {
    setLoadingAI(true);
    const summary = {
      score,
      state,
      totalTransactions: transactions.length,
      goals: goals.map(g => ({ name: g.name, progress: Math.round(((g.current_amount || 0) / g.target_amount) * 100) })),
      monthlyData: monthlyData.slice(-3),
    };
    const insight = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a friendly financial coach for a gamified finance app called Money Forest. 
Given this user's financial data: ${JSON.stringify(summary)}, 
write a short (3-4 sentences), warm, encouraging monthly forest report. 
Use nature/forest metaphors. Celebrate wins, gently suggest improvements. 
Start with an emoji. Be specific about their numbers. Keep it positive and motivating.`,
    });
    setAiInsight(insight);
    setLoadingAI(false);
  };

  const now = new Date();
  const thisMonth = transactions.filter(t => {
    const d = new Date(t.date);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });

  const netSavings = thisMonth.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0)
    - thisMonth.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);

  const topExpCat = useMemo(() => {
    const cats = {};
    thisMonth.filter(t => t.type === 'expense').forEach(t => {
      cats[t.category] = (cats[t.category] || 0) + t.amount;
    });
    return Object.entries(cats).sort((a, b) => b[1] - a[1])[0];
  }, [thisMonth]);

  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 md:px-8 pt-6 pb-4">
        <h1 className="font-display text-2xl md:text-3xl font-semibold">Forest Report</h1>
        <p className="text-sm text-muted-foreground mt-1">{format(now, 'MMMM yyyy')}</p>
      </div>

      <div className="px-4 md:px-8 pb-10 space-y-5">
        {/* Forest summary card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-primary/10 via-card to-accent/5 border border-primary/20 rounded-2xl p-6"
        >
          <div className="flex items-start gap-6">
            <HealthScoreBadge score={score} size="lg" />
            <div className="flex-1">
              <h2 className="font-display font-semibold text-xl mb-2">{config.emoji} {config.label}</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">{forestMessage}</p>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[
                  { label: 'Net This Month', value: `${netSavings >= 0 ? '+' : ''}$${netSavings.toLocaleString()}`, positive: netSavings >= 0 },
                  { label: 'Top Spend', value: topExpCat ? topExpCat[0].replace(/_/g, ' ') : 'None', neutral: true },
                  { label: 'Active Goals', value: goals.filter(g => g.status === 'active').length, neutral: true },
                ].map((item, i) => (
                  <div key={i} className="bg-white/60 rounded-xl p-3">
                    <p className={`font-semibold text-sm ${item.neutral ? 'text-foreground' : item.positive ? 'text-green-600' : 'text-red-500'}`}>
                      {item.value}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">{item.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* AI Forest Insight */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card border border-border rounded-2xl p-5"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-accent" />
              <h2 className="font-semibold text-sm">AI Forest Insight</h2>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={generateAIInsight}
              disabled={loadingAI}
              className="text-xs h-8"
            >
              {loadingAI ? (
                <><Loader2 className="w-3 h-3 mr-1.5 animate-spin" />Thinking…</>
              ) : (
                <><RefreshCw className="w-3 h-3 mr-1.5" />Generate</>
              )}
            </Button>
          </div>

          {aiInsight ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-primary/5 border border-primary/10 rounded-xl p-4"
            >
              <p className="text-sm text-foreground leading-relaxed">{aiInsight}</p>
            </motion.div>
          ) : (
            <div className="flex flex-col items-center py-6 text-center">
              <span className="text-3xl mb-2">🌿</span>
              <p className="text-sm text-muted-foreground">Click Generate to get your personalized forest report.</p>
            </div>
          )}
        </motion.div>

        {/* 6-month chart */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card border border-border rounded-2xl p-5"
        >
          <h2 className="font-semibold text-sm mb-4">6-Month Overview</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthlyData} barSize={16} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} width={40} />
              <Tooltip
                contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 12, fontSize: 12 }}
                formatter={(val) => [`$${val}`, '']}
              />
              <Bar dataKey="income" fill="#22c55e" radius={[4, 4, 0, 0]} name="Income" />
              <Bar dataKey="expense" fill="#ef4444" radius={[4, 4, 0, 0]} name="Expense" />
              <Bar dataKey="savings" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Savings" />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-3">
            {[['#22c55e', 'Income'], ['#ef4444', 'Expenses'], ['#3b82f6', 'Savings']].map(([color, label]) => (
              <div key={label} className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
                <span className="text-xs text-muted-foreground">{label}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Goals breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card border border-border rounded-2xl p-5"
        >
          <h2 className="font-semibold text-sm mb-4">Goal Trees Status</h2>
          {goals.length > 0 ? (
            <div className="space-y-3">
              {goals.map(goal => {
                const progress = goal.target_amount > 0
                  ? Math.min(100, ((goal.current_amount || 0) / goal.target_amount) * 100)
                  : 0;
                const emoji = progress >= 100 ? '🌳✨' : progress >= 50 ? '🌲' : progress >= 25 ? '🌿' : '🌱';
                return (
                  <div key={goal.id} className="flex items-center gap-3">
                    <span className="text-xl w-7">{emoji}</span>
                    <div className="flex-1">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium">{goal.name}</span>
                        <span className="text-xs text-muted-foreground">
                          ${(goal.current_amount || 0).toLocaleString()} / ${goal.target_amount.toLocaleString()}
                        </span>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full">
                        <div
                          className={`h-full rounded-full transition-all ${goal.status === 'completed' ? 'bg-yellow-400' : 'bg-primary'}`}
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>
                    <span className={`text-xs font-semibold ml-2 ${goal.status === 'completed' ? 'text-yellow-600' : 'text-muted-foreground'}`}>
                      {goal.status === 'completed' ? '✓ Done' : `${Math.round(progress)}%`}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col items-center py-8 text-center">
              <span className="text-3xl mb-2">🌱</span>
              <p className="text-sm text-muted-foreground">No goal trees planted yet.</p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}