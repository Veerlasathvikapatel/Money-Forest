import { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { User, Mail, LogOut, Sprout, TreePine, Target, ArrowLeftRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';

export default function Profile() {
  const { user, logout } = useAuth();
  const [name, setName] = useState(user?.full_name || '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions'],
    queryFn: () => base44.entities.Transaction.list('-date', 100),
  });
  const { data: goals = [] } = useQuery({
    queryKey: ['goals'],
    queryFn: () => base44.entities.Goal.list('-created_date', 50),
  });

  const totalSaved = transactions
    .filter(t => t.type === 'savings' || t.type === 'investment')
    .reduce((s, t) => s + t.amount, 0);
  const completedGoals = goals.filter(g => g.status === 'completed').length;

  const handleSave = async () => {
    if (!name.trim()) return;
    setSaving(true);
    await base44.auth.updateMe({ full_name: name });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const initial = (user?.full_name || user?.email || '?')[0].toUpperCase();

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-xl mx-auto px-4 md:px-6 py-8">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>

          {/* Avatar + name */}
          <div className="flex flex-col items-center gap-3 mb-8">
            <div className="w-20 h-20 rounded-full bg-primary/15 border-4 border-primary/20 flex items-center justify-center">
              <span className="font-display text-3xl font-bold text-primary">{initial}</span>
            </div>
            <div className="text-center">
              <h1 className="font-display text-2xl font-semibold text-foreground">{user?.full_name || 'Forester'}</h1>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3 mb-8">
            {[
              { icon: TreePine, label: 'Active Goals', value: goals.filter(g => g.status === 'active').length, color: 'text-green-600', bg: 'bg-green-50' },
              { icon: Target, label: 'Completed', value: completedGoals, color: 'text-yellow-600', bg: 'bg-yellow-50' },
              { icon: ArrowLeftRight, label: 'Total Saved', value: `$${Math.round(totalSaved / 100) * 100 > 999 ? (totalSaved / 1000).toFixed(1) + 'k' : totalSaved.toLocaleString()}`, color: 'text-blue-600', bg: 'bg-blue-50' },
            ].map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="bg-card border border-border rounded-2xl p-4 text-center">
                  <div className={`w-8 h-8 ${s.bg} rounded-xl flex items-center justify-center mx-auto mb-2`}>
                    <Icon className={`w-4 h-4 ${s.color}`} />
                  </div>
                  <p className="font-bold text-foreground">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              );
            })}
          </div>

          {/* Edit name */}
          <div className="bg-card border border-border rounded-2xl p-5 mb-4">
            <h2 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <User className="w-4 h-4 text-muted-foreground" /> Account Details
            </h2>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-muted-foreground font-medium mb-1.5 block">Display Name</label>
                <Input
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Your name"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground font-medium mb-1.5 block">Email</label>
                <div className="flex items-center gap-2 h-9 px-3 rounded-md border border-input bg-muted/40">
                  <Mail className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{user?.email}</span>
                </div>
              </div>
              <Button
                onClick={handleSave}
                disabled={saving || !name.trim()}
                className="w-full"
              >
                {saving ? 'Saving…' : saved ? '✓ Saved!' : 'Save Changes'}
              </Button>
            </div>
          </div>

          {/* Navigation links */}
          <div className="bg-card border border-border rounded-2xl p-5 mb-4 space-y-1">
            <h2 className="font-semibold text-foreground mb-3 flex items-center gap-2">
              <Sprout className="w-4 h-4 text-muted-foreground" /> Navigate
            </h2>
            {[
              { to: '/Forest', label: '🌳 My Forest' },
              { to: '/Goals', label: '🎯 Goals' },
              { to: '/Transactions', label: '💸 Transactions' },
              { to: '/Budgets', label: '💰 Budgets' },
              { to: '/Habits', label: '🔥 Habits' },
              { to: '/Report', label: '📊 Forest Report' },
            ].map(({ to, label }) => (
              <Link key={to} to={to}>
                <div className="flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-muted transition-colors text-sm text-foreground">
                  <span>{label}</span>
                  <span className="text-muted-foreground">→</span>
                </div>
              </Link>
            ))}
          </div>

          {/* Logout */}
          <Button
            variant="outline"
            className="w-full border-destructive/30 text-destructive hover:bg-destructive/5"
            onClick={() => logout()}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </motion.div>
      </div>
    </div>
  );
}