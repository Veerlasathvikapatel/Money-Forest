import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { motion } from 'framer-motion';
import ForestScene from '@/components/forest/ForestScene';
import HealthScoreBadge from '@/components/forest/HealthScoreBadge';
import QuickAddTransaction from '@/components/transactions/QuickAddTransaction';
import { calculateHealthScore, getForestState, getForestConfig, generateForestMessage } from '@/lib/forestEngine';
import { Leaf, Droplets, Wind } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Forest() {
  const { user } = useAuth();

  const { data: transactions = [], refetch: refetchTx } = useQuery({
    queryKey: ['transactions', user?.email],
    queryFn: () => base44.entities.Transaction.filter({ created_by: user.email }, '-date', 100),
    enabled: !!user?.email,
  });

  const { data: goals = [] } = useQuery({
    queryKey: ['goals', user?.email],
    queryFn: () => base44.entities.Goal.filter({ created_by: user.email }, '-created_date', 20),
    enabled: !!user?.email,
  });

  const score = useMemo(() => calculateHealthScore(transactions), [transactions]);
  const state = getForestState(score);
  const config = getForestConfig(state);
  const message = useMemo(() => generateForestMessage(transactions, goals, score), [transactions, goals, score]);

  const totalSaved = transactions
    .filter(t => t.type === 'savings' || t.type === 'investment')
    .reduce((s, t) => s + t.amount, 0);

  const thisMonthExpenses = useMemo(() => {
    const now = new Date();
    return transactions
      .filter(t => {
        const d = new Date(t.date);
        return t.type === 'expense' && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      })
      .reduce((s, t) => s + t.amount, 0);
  }, [transactions]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="px-4 md:px-8 pt-6 pb-4 flex items-start justify-between">
        <div>
          <h1 className="font-display text-2xl md:text-3xl font-semibold text-foreground">Your Forest</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <QuickAddTransaction onAdded={() => refetchTx()} />
      </div>

      {/* Forest Scene */}
      <div className="px-4 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl overflow-hidden shadow-lg border border-border"
          style={{ height: 'clamp(220px, 40vw, 380px)' }}
        >
          <ForestScene score={score} goals={goals.filter(g => g.status === 'active')} />
        </motion.div>
      </div>

      {/* Forest Status Bar */}
      <div className="px-4 md:px-8 mt-4">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card border border-border rounded-2xl p-4 flex items-center gap-4"
        >
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm text-foreground mb-1">{config.emoji} {config.label}</p>
            <p className="text-xs text-muted-foreground leading-relaxed">{message}</p>
          </div>
          <HealthScoreBadge score={score} size="sm" />
        </motion.div>
      </div>

      {/* Quick Stats */}
      <div className="px-4 md:px-8 mt-4 grid grid-cols-3 gap-3">
        {[
          { label: 'Total Saved', value: `$${totalSaved.toLocaleString()}`, icon: Leaf, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'This Month Spent', value: `$${thisMonthExpenses.toLocaleString()}`, icon: Droplets, color: 'text-blue-500', bg: 'bg-blue-50' },
          { label: 'Active Goals', value: goals.filter(g => g.status === 'active').length, icon: Wind, color: 'text-purple-500', bg: 'bg-purple-50' },
        ].map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.1 }}
              className="bg-card border border-border rounded-2xl p-4"
            >
              <div className={`w-8 h-8 ${stat.bg} rounded-xl flex items-center justify-center mb-2`}>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </div>
              <p className="font-semibold text-foreground text-base">{stat.value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Goal trees preview */}
      {goals.filter(g => g.status === 'active').length > 0 && (
        <div className="px-4 md:px-8 mt-6 mb-8">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display font-semibold text-lg text-foreground">Goal Trees</h2>
            <Link to="/Goals" className="text-xs text-primary hover:underline font-medium">View all →</Link>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {goals.filter(g => g.status === 'active').slice(0, 4).map(goal => {
              const progress = goal.target_amount > 0
                ? Math.min(100, ((goal.current_amount || 0) / goal.target_amount) * 100)
                : 0;
              return (
                <div key={goal.id} className="shrink-0 bg-card border border-border rounded-xl p-3 w-28 text-center">
                  <div className="text-2xl mb-1">
                    {progress >= 100 ? '🌳✨' : progress >= 50 ? '🌲' : progress >= 25 ? '🌿' : '🌱'}
                  </div>
                  <p className="text-xs font-medium truncate">{goal.name}</p>
                  <p className="text-xs text-muted-foreground">{Math.round(progress)}%</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty state */}
      {goals.length === 0 && transactions.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="px-4 md:px-8 mt-6 mb-8"
        >
          <div className="bg-card border border-dashed border-primary/30 rounded-2xl p-8 text-center">
            <div className="text-5xl mb-3">🌱</div>
            <h3 className="font-display font-semibold text-lg mb-2">Plant your first seed</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Create a goal and log your first transaction to watch your forest come to life.
            </p>
            <div className="flex gap-3 justify-center">
              <Link to="/Goals">
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity">
                  Create a Goal
                </button>
              </Link>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}