import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { motion } from 'framer-motion';
import { format, subDays, eachDayOfInterval } from 'date-fns';
import { Flame, Leaf, Shield, TrendingUp, Target } from 'lucide-react';
import { cn } from '@/lib/utils';

function computeStreak(transactions) {
  if (!transactions.length) return 0;
  const dates = new Set(transactions.map(t => t.date));
  let streak = 0;
  let cursor = new Date();
  while (true) {
    const d = format(cursor, 'yyyy-MM-dd');
    if (dates.has(d)) {
      streak++;
      cursor = subDays(cursor, 1);
    } else {
      break;
    }
  }
  return streak;
}

function computeSavingStreak(transactions) {
  // Count consecutive months with savings
  let streak = 0;
  let cursor = new Date();
  for (let i = 0; i < 12; i++) {
    const month = format(subDays(cursor, i * 30), 'yyyy-MM');
    const hasSaving = transactions.some(t => t.type === 'savings' && t.date?.startsWith(month));
    if (hasSaving) streak++;
    else break;
  }
  return streak;
}

export default function Habits() {
  const { user } = useAuth();

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', user?.email],
    queryFn: () => base44.entities.Transaction.filter({ created_by: user.email }, '-date', 200),
    enabled: !!user?.email,
  });

  const { data: goals = [] } = useQuery({
    queryKey: ['goals', user?.email],
    queryFn: () => base44.entities.Goal.filter({ created_by: user.email }, '-created_date', 20),
    enabled: !!user?.email,
  });

  const logStreak = useMemo(() => computeStreak(transactions), [transactions]);
  const savingStreak = useMemo(() => computeSavingStreak(transactions), [transactions]);
  const completedGoals = goals.filter(g => g.status === 'completed').length;

  // Activity heatmap - last 30 days
  const last30Days = useMemo(() => {
    const end = new Date();
    const start = subDays(end, 29);
    const days = eachDayOfInterval({ start, end });
    const txDates = new Set(transactions.map(t => t.date));
    return days.map(d => ({
      date: format(d, 'yyyy-MM-dd'),
      label: format(d, 'd'),
      active: txDates.has(format(d, 'yyyy-MM-dd')),
    }));
  }, [transactions]);

  const badges = [
    {
      id: 'first_log',
      label: 'First Leaf',
      desc: 'Log your first transaction',
      emoji: '🍃',
      earned: transactions.length >= 1,
    },
    {
      id: 'saver',
      label: 'Seed Planter',
      desc: 'Make your first savings',
      emoji: '🌱',
      earned: transactions.some(t => t.type === 'savings'),
    },
    {
      id: 'goal_maker',
      label: 'Tree Grower',
      desc: 'Create your first goal',
      emoji: '🌳',
      earned: goals.length >= 1,
    },
    {
      id: 'goal_done',
      label: 'Harvest Moon',
      desc: 'Complete a financial goal',
      emoji: '🌕',
      earned: completedGoals >= 1,
    },
    {
      id: 'streak_3',
      label: 'Forest Keeper',
      desc: 'Log transactions 3 days in a row',
      emoji: '🔥',
      earned: logStreak >= 3,
    },
    {
      id: 'streak_7',
      label: 'Garden Master',
      desc: 'Log transactions 7 days in a row',
      emoji: '🏆',
      earned: logStreak >= 7,
    },
    {
      id: 'investor',
      label: 'Root Deep',
      desc: 'Make your first investment',
      emoji: '💎',
      earned: transactions.some(t => t.type === 'investment'),
    },
    {
      id: 'multi_goals',
      label: 'Forest Architect',
      desc: 'Have 3 or more active goals',
      emoji: '🌲',
      earned: goals.filter(g => g.status === 'active').length >= 3,
    },
  ];

  const earnedCount = badges.filter(b => b.earned).length;

  const streakItems = [
    { label: 'Logging Streak', value: logStreak, unit: 'days', icon: Flame, color: 'text-orange-500', bg: 'bg-orange-50' },
    { label: 'Saving Streak', value: savingStreak, unit: 'months', icon: Leaf, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'Goals Completed', value: completedGoals, unit: 'total', icon: Target, color: 'text-yellow-600', bg: 'bg-yellow-50' },
    { label: 'Total Logged', value: transactions.length, unit: 'entries', icon: TrendingUp, color: 'text-blue-500', bg: 'bg-blue-50' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="px-4 md:px-8 pt-6 pb-4">
        <h1 className="font-display text-2xl md:text-3xl font-semibold">Habits & Streaks</h1>
        <p className="text-sm text-muted-foreground mt-1">Your financial consistency</p>
      </div>

      <div className="px-4 md:px-8 pb-10 space-y-6">
        {/* Streak stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {streakItems.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="bg-card border border-border rounded-2xl p-4"
              >
                <div className={`w-9 h-9 ${item.bg} rounded-xl flex items-center justify-center mb-3`}>
                  <Icon className={`w-4 h-4 ${item.color}`} />
                </div>
                <p className="font-display text-2xl font-bold text-foreground">{item.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{item.label}</p>
                <p className="text-xs text-muted-foreground opacity-60">{item.unit}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Activity heatmap */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card border border-border rounded-2xl p-5"
        >
          <h2 className="font-semibold text-sm mb-4">30-Day Activity</h2>
          <div className="grid grid-cols-10 gap-1.5">
            {last30Days.map(day => (
              <div
                key={day.date}
                title={day.date}
                className={cn(
                  'aspect-square rounded-md transition-colors',
                  day.active
                    ? 'bg-primary hover:bg-primary/80'
                    : 'bg-muted hover:bg-muted/80'
                )}
              />
            ))}
          </div>
          <div className="flex items-center gap-3 mt-3">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-primary" />
              <span className="text-xs text-muted-foreground">Active day</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-muted" />
              <span className="text-xs text-muted-foreground">No activity</span>
            </div>
          </div>
        </motion.div>

        {/* Forest effects banner */}
        {logStreak > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 rounded-2xl p-5"
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl">{logStreak >= 7 ? '🦋' : logStreak >= 3 ? '🐦' : '🍃'}</span>
              <div>
                <p className="font-semibold text-sm">
                  {logStreak >= 7
                    ? 'Butterflies are dancing in your forest!'
                    : logStreak >= 3
                    ? 'Birds have arrived in your forest!'
                    : 'Your forest noticed your consistency!'}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {logStreak} day streak — keep going to unlock more forest life
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Badges */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-card border border-border rounded-2xl p-5"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-sm">Forest Badges</h2>
            <span className="text-xs text-muted-foreground">{earnedCount} / {badges.length} earned</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {badges.map(badge => (
              <div
                key={badge.id}
                className={cn(
                  'rounded-xl border p-3 text-center transition-all',
                  badge.earned
                    ? 'bg-primary/5 border-primary/20'
                    : 'bg-muted/30 border-border opacity-50 grayscale'
                )}
              >
                <span className="text-2xl block mb-1">{badge.emoji}</span>
                <p className={cn('text-xs font-semibold', badge.earned ? 'text-foreground' : 'text-muted-foreground')}>
                  {badge.label}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5 leading-tight">{badge.desc}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}