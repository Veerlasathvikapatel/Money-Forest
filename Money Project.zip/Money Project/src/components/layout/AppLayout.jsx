import { useState } from 'react';
import { Link, useLocation, Outlet } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  TreePine, LayoutDashboard, ArrowLeftRight, Target, BarChart3,
  Menu, X, Leaf, Sprout, Wallet, Flame, User
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/lib/AuthContext';

const navItems = [
  { path: '/Forest', label: 'My Forest', icon: TreePine },
  { path: '/Dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/Transactions', label: 'Transactions', icon: ArrowLeftRight },
  { path: '/Goals', label: 'Goals', icon: Target },
  { path: '/Budgets', label: 'Budgets', icon: Wallet },
  { path: '/Habits', label: 'Habits', icon: Flame },
  { path: '/Report', label: 'Forest Report', icon: BarChart3 },
];

export default function AppLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { user } = useAuth();
  const initial = (user?.full_name || user?.email || '?')[0].toUpperCase();

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 shrink-0 bg-sidebar border-r border-sidebar-border overflow-y-auto">
        <div className="flex items-center gap-3 px-6 py-6 border-b border-sidebar-border">
          <div className="w-9 h-9 rounded-xl bg-sidebar-primary/20 flex items-center justify-center">
            <Sprout className="w-5 h-5 text-sidebar-primary" />
          </div>
          <div>
            <h1 className="font-display text-sidebar-foreground font-semibold text-lg leading-tight">Money Forest</h1>
            <p className="text-xs text-sidebar-foreground/50">Your financial garden</p>
          </div>
        </div>

        <nav className="flex-1 px-3 py-6 space-y-1">
          {navItems.map(({ path, label, icon: Icon }) => {
            const active = location.pathname === path;
            return (
              <Link key={path} to={path}>
                <motion.div
                  whileHover={{ x: 4 }}
                  className={cn(
                    'flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors',
                    active
                      ? 'bg-sidebar-primary/20 text-sidebar-primary'
                      : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground'
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {label}
                  {active && (
                    <motion.div
                      layoutId="nav-indicator"
                      className="ml-auto w-1.5 h-1.5 rounded-full bg-sidebar-primary"
                    />
                  )}
                </motion.div>
              </Link>
            );
          })}
        </nav>

        <div className="px-4 py-4 border-t border-sidebar-border">
          <Link to="/Profile">
            <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-sidebar-accent transition-colors cursor-pointer">
              <div className="w-7 h-7 rounded-full bg-sidebar-primary/20 flex items-center justify-center shrink-0">
                <span className="text-xs font-bold text-sidebar-primary">{initial}</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-sidebar-foreground truncate">{user?.full_name || user?.email || 'My Account'}</p>
                <p className="text-xs text-sidebar-foreground/40 flex items-center gap-1 mt-0.5"><Leaf className="w-2.5 h-2.5" /> forest is alive</p>
              </div>
            </div>
          </Link>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="fixed top-0 left-0 right-0 z-50 flex md:hidden items-center justify-between px-4 py-3 bg-sidebar border-b border-sidebar-border">
        <div className="flex items-center gap-2">
          <Sprout className="w-5 h-5 text-sidebar-primary" />
          <span className="font-display text-sidebar-foreground font-semibold">Money Forest</span>
        </div>
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-2 rounded-lg text-sidebar-foreground/70 hover:text-sidebar-foreground"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Nav Overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 md:hidden"
            onClick={() => setMobileOpen(false)}
          >
            <div className="absolute inset-0 bg-black/50" />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25 }}
              className="absolute left-0 top-0 bottom-0 w-64 bg-sidebar flex flex-col overflow-y-auto"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center gap-3 px-6 py-6 border-b border-sidebar-border mt-12">
                <div className="w-8 h-8 rounded-xl bg-sidebar-primary/20 flex items-center justify-center">
                  <Sprout className="w-4 h-4 text-sidebar-primary" />
                </div>
                <span className="font-display text-sidebar-foreground font-semibold">Money Forest</span>
              </div>
              <nav className="flex-1 px-3 py-6 space-y-1">
                {navItems.map(({ path, label, icon: Icon }) => {
                  const active = location.pathname === path;
                  return (
                    <Link key={path} to={path} onClick={() => setMobileOpen(false)}>
                      <div className={cn(
                        'flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium',
                        active
                          ? 'bg-sidebar-primary/20 text-sidebar-primary'
                          : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground'
                      )}>
                        <Icon className="w-4 h-4" />
                        {label}
                      </div>
                    </Link>
                  );
                })}
              </nav>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 overflow-auto pt-14 md:pt-0">
        <Outlet />
      </main>
    </div>
  );
}