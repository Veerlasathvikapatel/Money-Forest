import { motion } from 'framer-motion';
import { getTreeStage } from '@/lib/forestEngine';
import { cn } from '@/lib/utils';

const GOAL_ICONS = {
  emergency: '🛡️',
  travel: '✈️',
  education: '📚',
  gadget: '💻',
  home: '🏠',
  car: '🚗',
  wedding: '💍',
  other: '⭐',
};

const STAGE_VISUALS = {
  sapling: { h: 44, emoji: '🌱', label: 'Sapling', color: 'text-lime-600' },
  young: { h: 64, emoji: '🌿', label: 'Young Tree', color: 'text-green-500' },
  medium: { h: 80, emoji: '🌳', label: 'Growing Tree', color: 'text-green-600' },
  large: { h: 96, emoji: '🌲', label: 'Large Tree', color: 'text-green-700' },
  mature: { h: 110, emoji: '🌳✨', label: 'Mature Tree', color: 'text-emerald-700' },
};

export default function GoalTree({ goal }) {
  const progress = goal.target_amount > 0
    ? Math.min(100, ((goal.current_amount || 0) / goal.target_amount) * 100)
    : 0;
  const stage = getTreeStage(progress);
  const visual = STAGE_VISUALS[stage];
  const goalIcon = GOAL_ICONS[goal.icon] || '⭐';

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ type: 'spring', stiffness: 300 }}
      className="bg-card border border-border rounded-2xl p-5 flex flex-col items-center gap-3 cursor-pointer hover:shadow-md transition-shadow"
    >
      {/* Tree visual */}
      <div className="flex flex-col items-center gap-1">
        <span className="text-4xl leading-none">{visual.emoji}</span>
        <span className={cn('text-xs font-medium', visual.color)}>{visual.label}</span>
      </div>

      {/* Goal info */}
      <div className="text-center">
        <div className="flex items-center justify-center gap-1.5 mb-1">
          <span>{goalIcon}</span>
          <span className="font-semibold text-sm text-foreground truncate max-w-[100px]">{goal.name}</span>
        </div>
        <p className="text-xs text-muted-foreground">
          ${(goal.current_amount || 0).toLocaleString()} / ${goal.target_amount.toLocaleString()}
        </p>
      </div>

      {/* Progress bar */}
      <div className="w-full">
        <div className="flex justify-between text-xs text-muted-foreground mb-1">
          <span>Progress</span>
          <span className="font-medium text-foreground">{Math.round(progress)}%</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1, ease: 'easeOut', delay: 0.3 }}
            className={cn(
              'h-full rounded-full',
              progress >= 100 ? 'bg-yellow-400' :
              progress >= 60 ? 'bg-green-500' :
              progress >= 30 ? 'bg-lime-500' :
              'bg-emerald-400'
            )}
          />
        </div>
      </div>

      {goal.status === 'completed' && (
        <span className="text-xs font-semibold text-yellow-600 bg-yellow-50 px-2.5 py-1 rounded-full border border-yellow-200">
          🎉 Completed!
        </span>
      )}
    </motion.div>
  );
}