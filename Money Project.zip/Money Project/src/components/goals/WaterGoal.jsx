import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Droplets } from 'lucide-react';

export default function WaterGoal({ goal }) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (newAmount) => base44.entities.Goal.update(goal.id, {
      current_amount: (goal.current_amount || 0) + newAmount,
      status: (goal.current_amount || 0) + newAmount >= goal.target_amount ? 'completed' : 'active',
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['goals'] });
      setOpen(false);
      setAmount('');
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate(parseFloat(amount));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="rounded-lg gap-1.5">
          <Droplets className="w-3.5 h-3.5" />
          Water
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Water "{goal.name}"</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Current: ${(goal.current_amount || 0).toLocaleString()} / ${(goal.target_amount || 0).toLocaleString()}
          </p>
          <Input
            type="number"
            step="0.01"
            placeholder="Amount to add ($)"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            required
            autoFocus
          />
          <Button type="submit" className="w-full" disabled={!amount || mutation.isPending}>
            {mutation.isPending ? 'Watering...' : '💧 Water Tree'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}