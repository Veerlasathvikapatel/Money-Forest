import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Heart, Plane, GraduationCap, Smartphone, Home, Car, Package } from 'lucide-react';
import { cn } from "@/lib/utils";

const iconOptions = [
  { value: 'emergency', label: 'Emergency', icon: Heart },
  { value: 'travel', label: 'Travel', icon: Plane },
  { value: 'education', label: 'Education', icon: GraduationCap },
  { value: 'gadget', label: 'Gadget', icon: Smartphone },
  { value: 'home', label: 'Home', icon: Home },
  { value: 'car', label: 'Car', icon: Car },
  { value: 'other', label: 'Other', icon: Package },
];

export default function GoalForm() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [icon, setIcon] = useState('');
  const [deadline, setDeadline] = useState('');
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.Goal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['goals'] });
      setOpen(false);
      setName('');
      setTargetAmount('');
      setIcon('');
      setDeadline('');
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate({
      name,
      target_amount: parseFloat(targetAmount),
      current_amount: 0,
      icon: icon || 'other',
      deadline: deadline || undefined,
      status: 'active',
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-primary hover:bg-primary/90 rounded-xl gap-2">
          <Plus className="w-4 h-4" />
          Plant a Tree
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">Plant a New Goal Tree</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          <Input
            placeholder="Goal name (e.g., Travel to Japan)"
            value={name}
            onChange={e => setName(e.target.value)}
            required
          />

          <Input
            type="number"
            step="0.01"
            placeholder="Target amount ($)"
            value={targetAmount}
            onChange={e => setTargetAmount(e.target.value)}
            required
          />

          {/* Icon selector */}
          <div>
            <p className="text-sm text-muted-foreground mb-2">Choose your tree type</p>
            <div className="grid grid-cols-4 gap-2">
              {iconOptions.map(opt => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setIcon(opt.value)}
                  className={cn(
                    "flex flex-col items-center gap-1 p-3 rounded-xl border-2 transition-all text-xs",
                    icon === opt.value
                      ? "border-primary bg-primary/5 text-primary"
                      : "border-border hover:bg-muted"
                  )}
                >
                  <opt.icon className="w-4 h-4" />
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-1">Deadline (optional)</p>
            <Input
              type="date"
              value={deadline}
              onChange={e => setDeadline(e.target.value)}
            />
          </div>

          <Button type="submit" className="w-full h-11" disabled={!name || !targetAmount || mutation.isPending}>
            {mutation.isPending ? 'Planting...' : '🌱 Plant Tree'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}