import React from 'react';
import { format } from 'date-fns';
import { TrendingUp, TrendingDown, PiggyBank, BarChart3, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const typeIcons = {
  income: TrendingUp,
  expense: TrendingDown,
  savings: PiggyBank,
  investment: BarChart3,
};

const typeColors = {
  income: 'bg-emerald-100 text-emerald-600',
  expense: 'bg-red-100 text-red-600',
  savings: 'bg-blue-100 text-blue-600',
  investment: 'bg-purple-100 text-purple-600',
};

export default function TransactionList({ transactions, onDelete }) {
  if (transactions.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <PiggyBank className="w-10 h-10 mx-auto mb-3 opacity-40" />
        <p className="text-sm">No transactions yet. Start logging!</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <AnimatePresence>
        {transactions.map((tx, i) => {
          const Icon = typeIcons[tx.type] || TrendingDown;
          const isPositive = tx.type === 'income';
          return (
            <motion.div
              key={tx.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ delay: i * 0.03 }}
              className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border hover:shadow-sm transition-shadow group"
            >
              <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", typeColors[tx.type])}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground capitalize">
                  {tx.category?.replace(/_/g, ' ')}
                </p>
                <p className="text-xs text-muted-foreground truncate">
                  {tx.note || format(new Date(tx.date), 'MMM d, yyyy')}
                </p>
              </div>
              <div className="text-right">
                <p className={cn("text-sm font-semibold", isPositive ? "text-emerald-600" : "text-foreground")}>
                  {isPositive ? '+' : '-'}${(tx.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground">{format(new Date(tx.date), 'MMM d')}</p>
              </div>
              {onDelete && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                  onClick={() => onDelete(tx.id)}
                >
                  <Trash2 className="w-3.5 h-3.5 text-muted-foreground" />
                </Button>
              )}
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}