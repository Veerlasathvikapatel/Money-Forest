import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { Plus, X, DollarSign, TrendingUp, PiggyBank, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const TYPES = [
  { value: 'income', label: 'Income', icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-50 border-green-200' },
  { value: 'expense', label: 'Expense', icon: TrendingDown, color: 'text-red-500', bg: 'bg-red-50 border-red-200' },
  { value: 'savings', label: 'Savings', icon: PiggyBank, color: 'text-blue-600', bg: 'bg-blue-50 border-blue-200' },
  { value: 'investment', label: 'Invest', icon: DollarSign, color: 'text-purple-600', bg: 'bg-purple-50 border-purple-200' },
];

const CATEGORIES = {
  income: ['salary', 'freelance', 'gift', 'other'],
  expense: ['food', 'transport', 'shopping', 'entertainment', 'bills', 'health', 'other'],
  savings: ['savings_deposit'],
  investment: ['investment_deposit'],
};

export default function QuickAddTransaction({ onAdded }) {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const queryClient = useQueryClient();

  const handleSubmit = async () => {
    if (!amount || isNaN(parseFloat(amount))) return;
    setLoading(true);
    const cat = category || CATEGORIES[type][0];
    await base44.entities.Transaction.create({
      type,
      amount: parseFloat(amount),
      category: cat,
      note,
      date: new Date().toISOString().split('T')[0],
    });
    queryClient.invalidateQueries({ queryKey: ['transactions'] });
    setAmount('');
    setNote('');
    setCategory('');
    setLoading(false);
    setOpen(false);
    onAdded?.();
  };

  const selectedType = TYPES.find(t => t.value === type);

  return (
    <>
      {/* FAB */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen(true)}
        className="fixed bottom-6 right-6 z-30 w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center md:hidden"
      >
        <Plus className="w-6 h-6" />
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          >
            <motion.div
              initial={{ y: 60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 60, opacity: 0 }}
              transition={{ type: 'spring', damping: 28 }}
              className="w-full max-w-sm bg-card rounded-2xl p-6 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-display font-semibold text-lg">Quick Add</h3>
                <button onClick={() => setOpen(false)} className="p-1.5 rounded-full hover:bg-muted text-muted-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Type selector */}
              <div className="grid grid-cols-4 gap-2 mb-4">
                {TYPES.map(t => {
                  const Icon = t.icon;
                  return (
                    <button
                      key={t.value}
                      onClick={() => { setType(t.value); setCategory(''); }}
                      className={cn(
                        'flex flex-col items-center gap-1 p-2.5 rounded-xl border text-xs font-medium transition-all',
                        type === t.value ? `${t.bg} ${t.color}` : 'border-border text-muted-foreground hover:bg-muted'
                      )}
                    >
                      <Icon className="w-4 h-4" />
                      {t.label}
                    </button>
                  );
                })}
              </div>

              {/* Amount */}
              <div className="relative mb-3">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">$</span>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  className="pl-7 text-lg font-semibold h-12"
                  autoFocus
                  onKeyDown={e => e.key === 'Enter' && handleSubmit()}
                />
              </div>

              {/* Category chips */}
              <div className="flex flex-wrap gap-1.5 mb-3">
                {CATEGORIES[type].map(cat => (
                  <button
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={cn(
                      'px-3 py-1 rounded-full text-xs capitalize transition-colors border',
                      category === cat
                        ? 'bg-primary text-primary-foreground border-primary'
                        : 'border-border text-muted-foreground hover:bg-muted'
                    )}
                  >
                    {cat.replace(/_/g, ' ')}
                  </button>
                ))}
              </div>

              {/* Note */}
              <Input
                placeholder="Add a note (optional)"
                value={note}
                onChange={e => setNote(e.target.value)}
                className="mb-4 text-sm"
                onKeyDown={e => e.key === 'Enter' && handleSubmit()}
              />

              <Button
                onClick={handleSubmit}
                disabled={!amount || loading}
                className="w-full h-11 font-semibold"
              >
                {loading ? 'Adding…' : `Log ${selectedType?.label}`}
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop button */}
      <Button
        onClick={() => setOpen(true)}
        className="hidden md:flex items-center gap-2"
      >
        <Plus className="w-4 h-4" />
        Add Transaction
      </Button>
    </>
  );
}