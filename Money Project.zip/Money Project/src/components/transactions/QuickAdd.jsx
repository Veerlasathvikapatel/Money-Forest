import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, DollarSign, TrendingUp, TrendingDown, PiggyBank, BarChart3 } from 'lucide-react';
import { cn } from "@/lib/utils";

const typeConfig = [
  { value: 'income', label: 'Income', icon: TrendingUp, color: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  { value: 'expense', label: 'Expense', icon: TrendingDown, color: 'bg-red-100 text-red-700 border-red-200' },
  { value: 'savings', label: 'Savings', icon: PiggyBank, color: 'bg-blue-100 text-blue-700 border-blue-200' },
  { value: 'investment', label: 'Investment', icon: BarChart3, color: 'bg-purple-100 text-purple-700 border-purple-200' },
];

const categoryMap = {
  income: ['salary', 'freelance', 'gift', 'other'],
  expense: ['food', 'transport', 'shopping', 'entertainment', 'bills', 'health', 'education', 'travel', 'other'],
  savings: ['savings_deposit', 'other'],
  investment: ['investment_deposit', 'other'],
};

export default function QuickAdd() {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [note, setNote] = useState('');
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.Transaction.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      setOpen(false);
      resetForm();
    },
  });

  const resetForm = () => {
    setAmount('');
    setCategory('');
    setNote('');
    setType('expense');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate({
      type,
      amount: parseFloat(amount),
      category: category || 'other',
      note,
      date: new Date().toISOString().split('T')[0],
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20 rounded-xl gap-2">
          <Plus className="w-4 h-4" />
          Quick Add
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">Add Transaction</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Type selector */}
          <div className="grid grid-cols-4 gap-2">
            {typeConfig.map(t => (
              <button
                key={t.value}
                type="button"
                onClick={() => { setType(t.value); setCategory(''); }}
                className={cn(
                  "flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-all text-xs font-medium",
                  type === t.value ? t.color : "border-border bg-card hover:bg-muted"
                )}
              >
                <t.icon className="w-4 h-4" />
                {t.label}
              </button>
            ))}
          </div>

          {/* Amount */}
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              step="0.01"
              placeholder="0.00"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              className="pl-9 text-lg h-12 font-medium"
              required
              autoFocus
            />
          </div>

          {/* Category */}
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger>
              <SelectValue placeholder="Choose category" />
            </SelectTrigger>
            <SelectContent>
              {(categoryMap[type] || []).map(c => (
                <SelectItem key={c} value={c}>
                  {c.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Note */}
          <Input
            placeholder="Add a note (optional)"
            value={note}
            onChange={e => setNote(e.target.value)}
          />

          <Button type="submit" className="w-full h-11" disabled={!amount || mutation.isPending}>
            {mutation.isPending ? 'Adding...' : 'Add Transaction'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}