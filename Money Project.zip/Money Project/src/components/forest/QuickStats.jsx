import React from 'react';
import { TrendingUp, TrendingDown, PiggyBank, BarChart3 } from 'lucide-react';
import { motion } from 'framer-motion';

const stats = [
  { key: 'totalIncome', label: 'Income', icon: TrendingUp, color: 'bg-emerald-50 text-emerald-600 border-emerald-100' },
  { key: 'totalExpenses', label: 'Expenses', icon: TrendingDown, color: 'bg-red-50 text-red-600 border-red-100' },
  { key: 'totalSavings', label: 'Savings', icon: PiggyBank, color: 'bg-blue-50 text-blue-600 border-blue-100' },
  { key: 'totalInvestments', label: 'Invested', icon: BarChart3, color: 'bg-purple-50 text-purple-600 border-purple-100' },
];

export default function QuickStats({ health }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {stats.map((stat, i) => {
        const Icon = stat.icon;
        const value = health[stat.key] || 0;
        return (
          <motion.div
            key={stat.key}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className={`rounded-xl border p-4 ${stat.color}`}
          >
            <div className="flex items-center gap-2 mb-1">
              <Icon className="w-4 h-4" />
              <span className="text-xs font-medium opacity-80">{stat.label}</span>
            </div>
            <p className="text-lg font-bold">${value.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</p>
          </motion.div>
        );
      })}
    </div>
  );
}