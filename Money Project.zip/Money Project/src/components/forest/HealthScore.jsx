import React from 'react';
import { motion } from 'framer-motion';
import { Heart, TrendingUp, TrendingDown, Leaf } from 'lucide-react';

const levelColors = {
  thriving: 'text-emerald-500',
  healthy: 'text-green-500',
  growing: 'text-lime-500',
  struggling: 'text-amber-500',
  wilting: 'text-red-500',
  new: 'text-blue-400',
};

const levelBgColors = {
  thriving: 'bg-emerald-500',
  healthy: 'bg-green-500',
  growing: 'bg-lime-500',
  struggling: 'bg-amber-500',
  wilting: 'bg-red-500',
  new: 'bg-blue-400',
};

export default function HealthScore({ health }) {
  const colorClass = levelColors[health.level] || 'text-green-500';
  const bgClass = levelBgColors[health.level] || 'bg-green-500';

  return (
    <div className="bg-card rounded-2xl border border-border p-6 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Leaf className="w-5 h-5 text-primary" />
        <h3 className="font-semibold text-foreground">Forest Health</h3>
      </div>

      {/* Score circle */}
      <div className="flex items-center justify-center mb-4">
        <div className="relative w-28 h-28">
          <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--border))" strokeWidth="8" />
            <motion.circle
              cx="50" cy="50" r="42"
              fill="none"
              stroke="currentColor"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={264}
              className={colorClass}
              initial={{ strokeDashoffset: 264 }}
              animate={{ strokeDashoffset: 264 - (264 * health.score / 100) }}
              transition={{ duration: 1.5, ease: 'easeOut' }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={`text-2xl font-bold ${colorClass}`}>{health.score}</span>
            <span className="text-xs text-muted-foreground">/ 100</span>
          </div>
        </div>
      </div>

      <div className="text-center mb-4">
        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium text-white ${bgClass}`}>
          <Heart className="w-3 h-3" />
          {health.level?.charAt(0).toUpperCase() + health.level?.slice(1)}
        </span>
        <p className="text-sm text-muted-foreground mt-2">{health.description}</p>
      </div>

      {/* Stats */}
      {health.totalIncome > 0 && (
        <div className="space-y-2 pt-4 border-t border-border">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Savings rate</span>
            <span className="font-medium flex items-center gap-1">
              {health.savingsRatio >= 20 ? <TrendingUp className="w-3 h-3 text-emerald-500" /> : <TrendingDown className="w-3 h-3 text-amber-500" />}
              {health.savingsRatio}%
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Expense rate</span>
            <span className="font-medium">{health.expenseRatio}%</span>
          </div>
        </div>
      )}
    </div>
  );
}