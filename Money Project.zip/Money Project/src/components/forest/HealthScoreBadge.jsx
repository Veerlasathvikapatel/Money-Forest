import { motion } from 'framer-motion';
import { getForestState, getForestConfig } from '@/lib/forestEngine';
import { cn } from '@/lib/utils';

export default function HealthScoreBadge({ score, size = 'md' }) {
  const state = getForestState(score);
  const config = getForestConfig(state);

  const radius = size === 'lg' ? 52 : 38;
  const stroke = size === 'lg' ? 6 : 5;
  const circumference = 2 * Math.PI * radius;
  const progress = (score / 100) * circumference;

  const colorMap = {
    thriving: '#22c55e',
    healthy: '#4ade80',
    growing: '#facc15',
    struggling: '#fb923c',
    wilting: '#f87171',
  };
  const color = colorMap[state];

  const textSize = size === 'lg' ? 'text-3xl' : 'text-xl';
  const dim = size === 'lg' ? 120 : 88;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative" style={{ width: dim, height: dim }}>
        <svg width={dim} height={dim} className="-rotate-90">
          <circle
            cx={dim / 2} cy={dim / 2} r={radius}
            fill="none" stroke="currentColor"
            strokeWidth={stroke}
            className="text-border"
          />
          <motion.circle
            cx={dim / 2} cy={dim / 2} r={radius}
            fill="none"
            stroke={color}
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: circumference - progress }}
            transition={{ duration: 1.2, ease: 'easeOut', delay: 0.2 }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={cn(textSize, 'font-bold font-display')} style={{ color }}>
            {score}
          </span>
          {size === 'lg' && <span className="text-xs text-muted-foreground">/ 100</span>}
        </div>
      </div>
      <div className="text-center">
        <p className="text-sm font-semibold text-foreground">{config.emoji} {config.label}</p>
        {size === 'lg' && (
          <p className="text-xs text-muted-foreground mt-1 max-w-[180px] text-center">{config.description}</p>
        )}
      </div>
    </div>
  );
}