import React from 'react';
import { motion } from 'framer-motion';
import { Target, Plane, GraduationCap, Smartphone, Home, Car, Heart, Package } from 'lucide-react';
import { Progress } from "@/components/ui/progress";

const goalIcons = {
  emergency: Heart,
  travel: Plane,
  education: GraduationCap,
  gadget: Smartphone,
  home: Home,
  car: Car,
  wedding: Heart,
  other: Package,
};

function GoalTree({ goal, index }) {
  const progress = Math.min(100, ((goal.current_amount || 0) / (goal.target_amount || 1)) * 100);
  const Icon = goalIcons[goal.icon] || Target;

  // Tree size based on progress
  const treeScale = 0.3 + (progress / 100) * 0.7;
  const hasFlowers = progress >= 80;
  const isComplete = progress >= 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="bg-card rounded-2xl border border-border p-5 shadow-sm hover:shadow-md transition-shadow"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
            <Icon className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h4 className="font-medium text-sm text-foreground">{goal.name}</h4>
            <p className="text-xs text-muted-foreground">
              {isComplete ? '🎉 Completed!' : `${Math.round(progress)}% grown`}
            </p>
          </div>
        </div>
      </div>

      {/* Mini tree visualization */}
      <div className="flex justify-center my-3">
        <svg width="80" height="80" viewBox="0 0 80 80">
          <motion.g
            initial={{ scale: 0 }}
            animate={{ scale: treeScale }}
            transition={{ duration: 0.8, type: 'spring' }}
            style={{ transformOrigin: '40px 70px' }}
          >
            <rect x={37} y={45} width={6} height={25} rx={2} fill="#6b4226" />
            <circle cx={40} cy={38} r={18} fill={isComplete ? '#16a34a' : '#4ade80'} />
            <circle cx={30} cy={42} r={12} fill={isComplete ? '#15803d' : '#22c55e'} />
            <circle cx={50} cy={42} r={12} fill={isComplete ? '#15803d' : '#22c55e'} />
            <circle cx={40} cy={30} r={10} fill={isComplete ? '#16a34a' : '#86efac'} opacity={0.7} />
            {hasFlowers && (
              <>
                <circle cx={30} cy={32} r={3} fill="#f472b6" />
                <circle cx={50} cy={35} r={3} fill="#fbbf24" />
                <circle cx={40} cy={25} r={3} fill="#a78bfa" />
              </>
            )}
          </motion.g>
        </svg>
      </div>

      <div className="space-y-2">
        <Progress value={progress} className="h-2" />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>${(goal.current_amount || 0).toLocaleString()}</span>
          <span>${(goal.target_amount || 0).toLocaleString()}</span>
        </div>
      </div>
    </motion.div>
  );
}

export default function GoalTrees({ goals }) {
  const activeGoals = goals.filter(g => g.status !== 'paused');

  if (activeGoals.length === 0) {
    return (
      <div className="bg-card rounded-2xl border border-border p-8 text-center shadow-sm">
        <Target className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
        <p className="text-sm text-muted-foreground">No goals yet. Plant your first tree!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {activeGoals.map((goal, i) => (
        <GoalTree key={goal.id} goal={goal} index={i} />
      ))}
    </div>
  );
}