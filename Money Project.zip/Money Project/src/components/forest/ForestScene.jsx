import { useEffect, useRef, useMemo } from 'react';
import { motion } from 'framer-motion';
import { getForestConfig, getForestState } from '@/lib/forestEngine';

// SVG tree components at different growth stages
function Tree({ x, y, stage = 'medium', delay = 0, color = '#2d6a4f' }) {
  const configs = {
    sapling: { h: 40, w: 20, trunkH: 15 },
    young: { h: 65, w: 35, trunkH: 20 },
    medium: { h: 90, w: 55, trunkH: 28 },
    large: { h: 120, w: 75, trunkH: 35 },
    mature: { h: 150, w: 95, trunkH: 42 },
  };
  const c = configs[stage] || configs.medium;

  return (
    <motion.g
      initial={{ scaleY: 0, opacity: 0 }}
      animate={{ scaleY: 1, opacity: 1 }}
      transition={{ delay, duration: 0.8, ease: 'easeOut' }}
      style={{ transformOrigin: `${x}px ${y}px` }}
    >
      {/* Trunk */}
      <rect
        x={x - 5}
        y={y - c.trunkH}
        width={10}
        height={c.trunkH}
        rx={3}
        fill="#8B5E3C"
      />
      {/* Canopy layers */}
      <ellipse cx={x} cy={y - c.trunkH - c.h * 0.55} rx={c.w * 0.5} ry={c.h * 0.35} fill={color} opacity={0.7} />
      <ellipse cx={x} cy={y - c.trunkH - c.h * 0.7} rx={c.w * 0.38} ry={c.h * 0.3} fill={color} opacity={0.85} />
      <ellipse cx={x} cy={y - c.trunkH - c.h * 0.9} rx={c.w * 0.25} ry={c.h * 0.25} fill={color} />

      {/* Flowers on mature trees */}
      {stage === 'mature' && (
        <>
          {[[-15, -c.trunkH - c.h * 0.55], [10, -c.trunkH - c.h * 0.65], [-5, -c.trunkH - c.h * 0.45]].map(([fx, fy], i) => (
            <circle key={i} cx={x + fx} cy={y + fy} r={5} fill="#FFB7C5" opacity={0.9} />
          ))}
        </>
      )}
    </motion.g>
  );
}

function Weed({ x, y, delay = 0 }) {
  return (
    <motion.g
      initial={{ scaleY: 0 }}
      animate={{ scaleY: 1 }}
      transition={{ delay, duration: 0.5 }}
      style={{ transformOrigin: `${x}px ${y}px` }}
    >
      <line x1={x} y1={y} x2={x - 8} y2={y - 20} stroke="#7a8c3a" strokeWidth={2} />
      <line x1={x} y1={y} x2={x + 8} y2={y - 18} stroke="#7a8c3a" strokeWidth={2} />
      <line x1={x} y1={y - 8} x2={x - 12} y2={y - 25} stroke="#8a9c3a" strokeWidth={1.5} />
      <ellipse cx={x - 8} cy={y - 20} rx={5} ry={4} fill="#8a9c3a" />
      <ellipse cx={x + 8} cy={y - 18} rx={5} ry={4} fill="#9aac4a" />
    </motion.g>
  );
}

function Flower({ x, y, color = '#FFB7C5', delay = 0 }) {
  return (
    <motion.g
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ delay, duration: 0.4, type: 'spring' }}
      style={{ transformOrigin: `${x}px ${y}px` }}
    >
      {[0, 60, 120, 180, 240, 300].map((angle, i) => (
        <ellipse
          key={i}
          cx={x + Math.cos((angle * Math.PI) / 180) * 6}
          cy={y + Math.sin((angle * Math.PI) / 180) * 6}
          rx={5}
          ry={3}
          fill={color}
          opacity={0.85}
          transform={`rotate(${angle} ${x} ${y})`}
        />
      ))}
      <circle cx={x} cy={y} r={4} fill="#FFE066" />
    </motion.g>
  );
}

function Cloud({ x, y, delay = 0, opacity = 0.9 }) {
  return (
    <motion.g
      initial={{ x: -30, opacity: 0 }}
      animate={{ x: 0, opacity }}
      transition={{ delay, duration: 1.5 }}
    >
      <motion.g
        animate={{ x: [0, 8, 0] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
      >
        <ellipse cx={x} cy={y} rx={28} ry={16} fill="white" opacity={0.9} />
        <ellipse cx={x - 15} cy={y + 5} rx={18} ry={12} fill="white" opacity={0.9} />
        <ellipse cx={x + 15} cy={y + 5} rx={20} ry={13} fill="white" opacity={0.9} />
        <ellipse cx={x} cy={y + 8} rx={32} ry={12} fill="white" opacity={0.95} />
      </motion.g>
    </motion.g>
  );
}

function Bird({ x, y, delay = 0 }) {
  return (
    <motion.g
      initial={{ x: -50, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ delay, duration: 1 }}
    >
      <motion.g
        animate={{ x: [0, 20, 40, 60], y: [0, -5, 2, -3], opacity: [1, 1, 1, 0] }}
        transition={{ duration: 8, repeat: Infinity, delay: delay * 3 }}
      >
        <path d={`M${x} ${y} q-5 -5 -10 0`} stroke="#555" strokeWidth={1.5} fill="none" />
        <path d={`M${x} ${y} q5 -5 10 0`} stroke="#555" strokeWidth={1.5} fill="none" />
      </motion.g>
    </motion.g>
  );
}

function Butterfly({ x, y, delay = 0 }) {
  return (
    <motion.g
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay, duration: 0.5 }}
    >
      <motion.g
        animate={{
          x: [0, 15, -10, 20, 0],
          y: [0, -10, 5, -8, 0],
        }}
        transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: delay * 2 }}
      >
        <motion.g
          animate={{ scaleX: [1, 0.3, 1, 0.3, 1] }}
          transition={{ duration: 0.4, repeat: Infinity }}
          style={{ transformOrigin: `${x}px ${y}px` }}
        >
          <ellipse cx={x - 6} cy={y - 2} rx={7} ry={5} fill="#F9A8D4" opacity={0.8} />
          <ellipse cx={x + 6} cy={y - 2} rx={7} ry={5} fill="#F9A8D4" opacity={0.8} />
          <ellipse cx={x - 5} cy={y + 4} rx={5} ry={4} fill="#FBCFE8" opacity={0.7} />
          <ellipse cx={x + 5} cy={y + 4} rx={5} ry={4} fill="#FBCFE8" opacity={0.7} />
          <line x1={x} y1={y - 6} x2={x} y2={y + 8} stroke="#78716c" strokeWidth={1} />
        </motion.g>
      </motion.g>
    </motion.g>
  );
}

function RainDrops() {
  const drops = useMemo(() =>
    Array.from({ length: 30 }, (_, i) => ({
      x: 10 + (i * 30) % 600,
      delay: (i * 0.15) % 2,
    })), []);

  return (
    <>
      {drops.map((d, i) => (
        <motion.line
          key={i}
          x1={d.x}
          y1={0}
          x2={d.x - 2}
          y2={12}
          stroke="#90caf9"
          strokeWidth={1}
          opacity={0.5}
          animate={{ y: [0, 280] }}
          transition={{ duration: 1.2, repeat: Infinity, delay: d.delay, ease: 'linear' }}
        />
      ))}
    </>
  );
}

export default function ForestScene({ score, goals = [] }) {
  const state = getForestState(score);
  const config = getForestConfig(state);

  const svgRef = useRef(null);
  const W = 700;
  const H = 380;

  // Generate trees based on goals + ambient trees
  const goalTrees = goals.slice(0, 5).map((goal, i) => {
    const progress = goal.target_amount > 0
      ? Math.min(100, (goal.current_amount || 0) / goal.target_amount * 100)
      : 0;
    const stages = ['sapling', 'young', 'medium', 'large', 'mature'];
    const stageIdx = Math.floor(progress / 25);
    const stage = stages[Math.min(stageIdx, 4)];
    const positions = [120, 200, 300, 420, 530];
    return { x: positions[i] || 120 + i * 120, y: H - 60, stage, delay: i * 0.15 };
  });

  // Background ambient trees
  const ambientTrees = config.treeLushness === 'bare' ? [] :
    config.treeLushness === 'sparse' ? [{ x: 60, y: H - 50, stage: 'young', delay: 0.5 }, { x: 620, y: H - 50, stage: 'young', delay: 0.6 }] :
    [
      { x: 55, y: H - 45, stage: 'medium', delay: 0.2 },
      { x: 650, y: H - 42, stage: 'medium', delay: 0.25 },
      ...(config.treeLushness === 'lush' ? [
        { x: 30, y: H - 35, stage: 'large', delay: 0.3 },
        { x: 670, y: H - 35, stage: 'large', delay: 0.35 },
      ] : [])
    ];

  const weeds = config.hasWeeds
    ? Array.from({ length: config.weedDensity === 'high' ? 12 : config.weedDensity === 'medium' ? 7 : 4 }, (_, i) => ({
        x: 80 + i * 55,
        y: H - 52,
        delay: i * 0.08,
      }))
    : [];

  const flowers = config.flowerDensity !== 'none'
    ? Array.from({ length: config.flowerDensity === 'high' ? 10 : config.flowerDensity === 'medium' ? 5 : 2 }, (_, i) => ({
        x: 100 + i * 60,
        y: H - 62,
        colors: ['#FFB7C5', '#FFE066', '#B5EAD7', '#FF9AA2', '#FFDAC1'],
        delay: i * 0.1,
      }))
    : [];

  return (
    <div className="w-full h-full rounded-2xl overflow-hidden relative" ref={svgRef}>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="w-full h-full"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <linearGradient id="skyGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={config.skyGradient[0]} />
            <stop offset="100%" stopColor={config.skyGradient[1]} />
          </linearGradient>
          <linearGradient id="groundGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={config.groundColor} />
            <stop offset="100%" stopColor="#2d4a2d" />
          </linearGradient>
          <radialGradient id="sunGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFE566" stopOpacity={config.sunOpacity} />
            <stop offset="100%" stopColor="#FFE566" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Sky */}
        <rect width={W} height={H} fill="url(#skyGradient)" />

        {/* Sun glow */}
        {config.hasSunshine && (
          <motion.g
            animate={{ opacity: [config.sunOpacity * 0.8, config.sunOpacity, config.sunOpacity * 0.8] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          >
            <circle cx={580} cy={60} r={60} fill="url(#sunGlow)" />
            <circle cx={580} cy={60} r={28} fill="#FFE566" opacity={config.sunOpacity} />
            <circle cx={580} cy={60} r={20} fill="#FFF0A0" opacity={config.sunOpacity} />
          </motion.g>
        )}

        {/* Clouds */}
        <Cloud x={120} y={55} delay={0} opacity={0.9} />
        <Cloud x={400} y={35} delay={0.5} opacity={0.7} />
        {config.hasSunshine && <Cloud x={250} y={70} delay={1} opacity={0.5} />}

        {/* Rain */}
        {config.hasRain && (
          <motion.g
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            <RainDrops />
          </motion.g>
        )}

        {/* Ground */}
        <ellipse cx={W / 2} cy={H - 20} rx={W * 0.6} ry={60} fill={config.groundColor} opacity={0.4} />
        <rect x={0} y={H - 55} width={W} height={80} fill="url(#groundGradient)" rx={30} />

        {/* Birds */}
        {Array.from({ length: config.birdCount }, (_, i) => (
          <Bird key={i} x={80 + i * 140} y={80 + (i % 3) * 20} delay={i * 0.5} />
        ))}

        {/* Ambient trees (background) */}
        {ambientTrees.map((t, i) => (
          <Tree key={`ambient-${i}`} x={t.x} y={t.y} stage={t.stage} delay={t.delay}
            color={config.treeLushness === 'lush' ? '#1a5c38' : '#3a6b48'} />
        ))}

        {/* Weeds */}
        {weeds.map((w, i) => <Weed key={i} x={w.x} y={w.y} delay={w.delay} />)}

        {/* Goal trees */}
        {goalTrees.map((t, i) => (
          <Tree key={`goal-${i}`} x={t.x} y={t.y} stage={t.stage} delay={t.delay}
            color={config.treeLushness === 'lush' ? '#2d6a4f' : '#4a8a5a'} />
        ))}

        {/* If no goals, show some default trees */}
        {goalTrees.length === 0 && (
          <>
            <Tree x={200} y={H - 60} stage="sapling" delay={0.2} color="#4a8a5a" />
            <Tree x={350} y={H - 60} stage="sapling" delay={0.4} color="#4a8a5a" />
            <Tree x={480} y={H - 60} stage="sapling" delay={0.6} color="#4a8a5a" />
          </>
        )}

        {/* Flowers */}
        {flowers.map((f, i) => (
          <Flower key={i} x={f.x} y={f.y}
            color={f.colors[i % f.colors.length]} delay={f.delay} />
        ))}

        {/* Butterflies */}
        {Array.from({ length: config.butterflyCount }, (_, i) => (
          <Butterfly key={i} x={150 + i * 100} y={H - 90 - i * 15} delay={i * 0.4} />
        ))}
      </svg>
    </div>
  );
}